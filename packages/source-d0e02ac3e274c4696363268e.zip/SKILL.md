---
name: pinecone:help
description: Overview of all available Pinecone skills and what a user needs to get started. Invoke when a user asks what skills are available, how to get started with Pinecone, or what they need to set up before using any Pinecone skill.
allowed-tools: Skill, Bash, Read
---

# Pinecone Skills — Help & Overview

Pinecone is the leading vector database for building accurate and performant AI applications at scale in production. It's useful for building semantic search, retrieval augmented generation, recommendation systems, and agentic applications.

Here's everything you need to get started and a summary of all available skills.

Invoke any skill from chat with `/pinecone:<skill-name>` — for example `/pinecone:quickstart` or `/pinecone:n8n`.

---

## What You Need

### Required
- **Pinecone account** — free to create at https://app.pinecone.io/?sessionType=signup
- **API key** — create one in the Pinecone console after signing up, then make it
  available to this environment:
  - Run `export PINECONE_API_KEY="your-key"` in your terminal. Claude Code reads
  your shell environment, so this is enough.
- To use a `.env` file instead, run scripts with `uv run --env-file .env scripts/...`.

### Optional (unlock more capabilities)

| Tool | What it enables | Install |
|---|---|---|
| **Pinecone MCP server** | Use Pinecone directly inside your AI agent/IDE without writing code | [Setup guide](https://docs.pinecone.io/guides/operations/mcp-server#tools) |
| **Pinecone CLI (`pc`)** | Manage all index types from the terminal, batch operations, backups, CI/CD | `brew tap pinecone-io/tap && brew install pinecone-io/tap/pinecone` |
| **uv** | Run the packaged Python scripts included in these skills | [Install uv](https://docs.astral.sh/uv/getting-started/installation/) |

---

## Available Skills

| Skill | What it does |
|---|---|
| `pinecone:quickstart` | Step-by-step onboarding — create an index, upload data, and run your first search |
| `pinecone:query` | Search integrated indexes using natural language text via the Pinecone MCP |
| `pinecone:cli` | Use the Pinecone CLI (`pc`) for terminal-based index and vector management |
| `pinecone:assistant` | Create, manage, and chat with Pinecone Assistants for document Q&A with citations |
| `pinecone:mcp` | Reference for all Pinecone MCP server tools and their parameters |
| `pinecone:full-text-search` | Build a full-text-search index — schema design, safe bulk ingestion, and query construction (`text` / `query_string` / dense / sparse scoring with text-match and metadata filters). **Document-schema API (`2026-07`); requires `pinecone` Python SDK ≥ 10.0.0.** |
| `pinecone:docs` | Curated links to official Pinecone documentation, organized by topic |
| `pinecone:n8n` | Build n8n workflows with the Pinecone Assistant node or Pinecone Vector Store node, including best practices and full workflow JSON generation |

---

## Which skill should I use?

**Just getting started?** → `pinecone:quickstart`

**Want to search an index you already have?**
- Integrated index (built-in embedding model) → `pinecone:query` (uses MCP)
- Any other index type → `pinecone:cli`

**Working with documents and Q&A?** → `pinecone:assistant`

**Building a full-text search index (BM25-style keyword/phrase matching, optionally combined with dense or sparse vectors)?** → `pinecone:full-text-search` (document-schema API, needs `pinecone` Python SDK ≥ 10.0.0)

**Building an n8n workflow with Pinecone (RAG pipeline, chat with docs)?** → `pinecone:n8n`

**Need to manage indexes, bulk upload vectors, or automate workflows?** → `pinecone:cli`

**Looking up API parameters or SDK usage?** → `pinecone:docs`

**Need to understand what MCP tools are available?** → `pinecone:mcp`

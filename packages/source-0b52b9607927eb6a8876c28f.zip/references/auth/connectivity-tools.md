# DSQL Connectivity & Data Loading Tools

Part of [DSQL Development Guide](../development-guide.md).

---

## Database Connectivity Tools

DSQL has many tools for connecting including 12 database drivers, 4 ORM libraries, and 4 specialized adapters
across various languages as listed in the [programming guide](https://docs.aws.amazon.com/aurora-dsql/latest/userguide/aws-sdks.html). PREFER using connectors, drivers, ORM libraries, and adapters.

### Database Drivers

Low-level libraries that directly connect to the database:

| Programming Language | Driver                           | Sample Repository                                                                                            |
| -------------------- | -------------------------------- | ------------------------------------------------------------------------------------------------------------ |
| **C++**              | libpq                            | [C++ libpq samples](https://github.com/aws-samples/aurora-dsql-samples/tree/main/cpp/libpq)                  |
| **C# (.NET)**        | Npgsql                           | [.NET Npgsql samples](https://github.com/aws-samples/aurora-dsql-samples/tree/main/dotnet/npgsql)            |
| **Go**               | pgx                              | [Go pgx samples](https://github.com/aws-samples/aurora-dsql-samples/tree/main/go/pgx)                        |
| **Java**             | pgJDBC                           | [Java pgJDBC samples](https://github.com/aws-samples/aurora-dsql-samples/tree/main/java/pgjdbc)              |
| **Java**             | DSQL Connector for JDBC          | JDBC samples                                                                                                 |
| **JavaScript**       | DSQL Connector for node-postgres | [Node.js samples](https://github.com/aws-samples/aurora-dsql-samples/tree/main/javascript/node-postgres)     |
| **JavaScript**       | DSQL Connector for Postgres.js   | [Postgres.js samples](https://github.com/aws-samples/aurora-dsql-samples/tree/main/javascript/postgres-js)   |
| **Python**           | Psycopg                          | [Python Psycopg samples](https://github.com/aws-samples/aurora-dsql-samples/tree/main/python/psycopg)        |
| **Python**           | DSQL Connector for Psycopg2      | [Python Psycopg2 samples](https://github.com/aws-samples/aurora-dsql-samples/tree/main/python/psycopg2)      |
| **Python**           | DSQL Connector for Asyncpg       | [Python Asyncpg samples](https://github.com/awslabs/aurora-dsql-python-connector/tree/main/examples/asyncpg) |
| **Ruby**             | pg                               | [Ruby pg samples](https://github.com/aws-samples/aurora-dsql-samples/tree/main/ruby/ruby-pg)                 |
| **Rust**             | SQLx                             | [Rust SQLx samples](https://github.com/aws-samples/aurora-dsql-samples/tree/main/rust/sqlx)                  |

### Object-Relational Mapping (ORM) Libraries

Standalone libraries that provide object-relational mapping functionality:

| Programming Language | ORM Library | Sample Repository                                                                                                 |
| -------------------- | ----------- | ----------------------------------------------------------------------------------------------------------------- |
| **Java**             | Hibernate   | [Hibernate Pet Clinic App](https://github.com/awslabs/aurora-dsql-hibernate/tree/main/examples/pet-clinic-app)    |
| **Python**           | SQLAlchemy  | [SQLAlchemy Pet Clinic App](https://github.com/awslabs/aurora-dsql-sqlalchemy/tree/main/examples/pet-clinic-app)  |
| **TypeScript**       | Sequelize   | [TypeScript Sequelize samples](https://github.com/aws-samples/aurora-dsql-samples/tree/main/typescript/sequelize) |
| **TypeScript**       | TypeORM     | [TypeScript TypeORM samples](https://github.com/aws-samples/aurora-dsql-samples/tree/main/typescript/type-orm)    |

### Aurora DSQL Adapters and Dialects

Specific extensions that make existing ORMs work with Aurora DSQL:

| Programming Language | ORM/Framework | Repository                                                                                          |
| -------------------- | ------------- | --------------------------------------------------------------------------------------------------- |
| **C# (.NET)**        | EF Core       | [Aurora DSQL EF Core Adapter](https://github.com/awslabs/aurora-dsql-orms/tree/main/dotnet/ef-core) |
| **Java**             | Hibernate     | [Aurora DSQL Hibernate Adapter](https://github.com/awslabs/aurora-dsql-hibernate/)                  |
| **Python**           | Django        | [Aurora DSQL Django Adapter](https://github.com/awslabs/aurora-dsql-django/)                        |
| **Python**           | SQLAlchemy    | [Aurora DSQL SQLAlchemy Adapter](https://github.com/awslabs/aurora-dsql-sqlalchemy/)                |

---

## Ad-hoc Queries: `aurora-dsql` MCP vs CLI/psql

For interactive/ad-hoc SQL against a cluster, there are two paths. Choose based on how the
`aurora-dsql` MCP server is configured — do not silently reconfigure it.

**The MCP server binds one cluster at startup.** Its `--cluster_endpoint` is a launch argument,
and the database tools (`readonly_query`, `transact`, `get_schema`) take no per-call endpoint —
so a running instance serves exactly the cluster it started with. Re-pointing it at a different
cluster requires editing `.mcp.json` and **restarting the session**. (This is unlike the
CloudWatch MCP used by Workflow 12, whose PromQL/`get_metric_data` tools accept `region` and
`cluster_id` as per-call arguments — so one running CloudWatch server can query clusters in any
PromQL-enabled region without reconfiguration, as long as each call passes the region where that
cluster's metrics live.)

**Decision rule:**

1. **MCP is configured for the target cluster** (its `--cluster_endpoint` matches) → use the
   `aurora-dsql` MCP tools. This is the preferred path for ad-hoc queries when it applies.
2. **MCP is unconfigured, disabled, or bound to a different cluster** → do **not** reconfigure it.
   Use the CLI + `psql` path via [`scripts/psql-connect.sh`](../../../../scripts/psql-connect.sh),
   which generates an IAM auth token and connects with `psql`:

   ```bash
   # Run a single statement against a specific cluster
   ./scripts/psql-connect.sh <cluster-id> --region <region> --command "SELECT count(*) FROM my_table"

   # Interactive session
   ./scripts/psql-connect.sh <cluster-id> --region <region>
   ```

   Note the script connects as the `admin` database user by default (override with `--user`), so
   the session has full read/write/DDL privileges — it is **not** read-only. Scope the SQL you run
   accordingly, and use a less-privileged `--user` when you only need reads. `--command` runs a
   single statement (it rejects multiple statements and comments). See
   [scripts/README.md](../../../../scripts/README.md) for the full flag set (`--user`, `--admin`,
   `--command`) and IAM prerequisites (`dsql:DbConnect` / `dsql:DbConnectAdmin`).
3. **You cannot confirm which cluster the MCP targets** → confirm first, or default to the
   CLI/psql path. Running against the wrong cluster is worse than the cost of checking.

The documentation-only MCP tools (`dsql_lint`, `dsql_search_documentation`,
`dsql_read_documentation`, `dsql_recommend`) require no cluster connection and are always safe.

---

## Data Loading Tools

The [DSQL Loader](https://github.com/aws-samples/aurora-dsql-loader) is a fast parallel data loader for DSQL that supports
loading from CSV, TSV, and Parquet files into DSQL with automatic schema detection and progress tracking.

Developers SHOULD PREFER the DSQL Loader for:

- quick, managed loading without user supervision
- populating test tables
- migrating data into DSQL from local files or S3 URIs of type csv, tsv, or parquet
- automated schema detection and progress tracking

ALWAYS use the loader's schema inference, PREFERRED to separate schema
creation for data migration.

**Install and use the DSQL Loader with [loader.sh](../../../../scripts/loader.sh)**

### Common Examples

**Load from S3:**

```bash
aurora-dsql-loader load \
  --endpoint your-cluster.dsql.us-east-1.on.aws \
  --source-uri s3://my-bucket/data.parquet \
  --table analytics_data
```

**Create table automatically from a local filepath:**

```bash
aurora-dsql-loader load \
  --endpoint your-cluster.dsql.us-east-1.on.aws \
  --source-uri data.csv \
  --table new_table \
  --if-not-exists
```

**Validate a local file without loading:**

```bash
aurora-dsql-loader load \
  --endpoint your-cluster.dsql.us-east-1.on.aws \
  --source-uri data.csv \
  --table my_table \
  --dry-run
```

### When to load the full reference

Load [data-loading.md](../data-loading.md) when diagnosing slow loads, configuring resume/retry, or tuning conflict handling.

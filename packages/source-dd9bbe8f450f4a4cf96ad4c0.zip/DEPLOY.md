# Deploying ManCo Reporting to Cloudflare

**Merging to `main` does not deploy this Worker.** Nothing in this repo's CI redeploys it —
`npx wrangler deploy` (below) is the only thing that does, and it is run by hand. A PR that
changes `server/worker.js` or bumps `BUDGET_BUNDLE_SCHEMA`/`ACCEPTED_BUDGET_BUNDLE_SCHEMAS`
is not live until someone with Cloudflare access runs that command — until then, the hosted
Worker keeps serving whatever it was last deployed with, however old. Treat "redeploy the
Worker" as part of landing such a PR, not a follow-up.

## Prerequisites

- `npx wrangler` (or `npm i -g wrangler`), authenticated to the target Cloudflare account
- A `wrangler.toml` — gitignored, because it carries account IDs, namespace IDs and
  customer slugs. Copy `wrangler.toml.example` to start.

### Scoping an API token

`wrangler login` cannot be granularly scoped. To use a scoped token, set `CLOUDFLARE_API_TOKEN`
and `CLOUDFLARE_ACCOUNT_ID` as environment variables instead. Minimum permissions:

| Scope | Permission | Needed for |
|---|---|---|
| Account | Workers Scripts → Edit | Uploading the script and its static assets |
| Account | Account Settings → Read | Account resolution |
| Zone | Workers Routes → Edit | Attaching or changing a hostname (drop it after first setup) |

`Workers KV Storage → Edit` is **not** required to deploy a Worker that merely *binds* KV — only
to read or write KV data directly (`wrangler kv key put`, etc.).

## Architecture

One Worker serves every customer. Each customer gets a vanity hostname,
`manco.<label>.carta.cloud`, attached as a Custom Domain.

The Worker serves the SPA via Cloudflare's asset binding (`run_worker_first = true`).
`webapp/src` is a symlink to `app/src` — wrangler follows it, so source changes deploy without a
build step. OAuth 2.1 with PKCE authenticates users against `mcp.app.carta.com`. Session tokens
and report data live in KV.

### Tenant isolation

Three checks run before any firm's data is read:

1. `tenantOf()` parses the Host header into a label and looks it up in the `TENANTS` map.
   An unmapped label yields a null UUID.
2. `tenantFirm()` asks Carta for that one firm: it calls MCP `set_context` with the label's
   UUID. Carta is the access check. It switches to the firm for a user who holds it, and for
   Carta staff (who reach any firm), and returns a plain "not found or not authorized" result
   for anyone else. The Worker never lists a user's firms on a vanity hostname, so a
   hostname can only ever open its own firm.
3. `authorizedFirm()` allows a firm only when it is that tenant firm and its slug matches
   the URL. The allow or deny is cached per session under `tenant-firm:<sid>:<firm_uuid>`.
   A failed Carta call is not cached.

Opening the bare hostname preselects the firm: `/api/app-config` returns it as `defaultFirm`
and `/api/firms` returns just that firm.

That cache key is per session on purpose. A shared key would let one user's successful
lookup satisfy the next user's request for the same firm.
`app/src/__tests__/workerTenancy.test.js` holds that contract.

**There is no `DEFAULT_FIRM`.** Setting one would pin every vanity hostname to a single firm's
data, which on a shared Worker means cross-tenant exposure.

### Session encryption

Each signed-in user's Carta access and refresh tokens are stored in KV under `session:<sid>`
as AES-GCM ciphertext. The key is the Worker secret `SESSION_KEY` (base64 of 32 random
bytes), so read access to KV alone yields nothing usable. The KV key name is bound into the
ciphertext, so a blob copied under another session's key does not open. A Worker without the
secret refuses to store a session; it never falls back to plaintext.

Set it once per Worker. **Each Worker gets its own key**, so one app cannot open another's
sessions:

```bash
openssl rand -base64 32 | wrangler-microapps secret put SESSION_KEY
```

Rotating the key signs every user out, which is the safe direction. Sessions written before
encryption existed read as signed out.

## Configuration

Copy `wrangler.toml.example` to `wrangler.toml` and fill in:

- `account_id` — the target Cloudflare account
- `[[kv_namespaces]].id` — the KV namespace backing sessions and report data. **Each app has its own
  namespace.** Never point two apps at one: cached firm data is keyed by firm, so the apps
  overwrite each other's (one app's snapshot replaced another's, and the second waited forever
  on a snapshot in the wrong shape). Create one with `wrangler kv namespace create manco-reporting-sessions`
- `[vars].TENANTS` — JSON mapping each URL label to the firm UUID it may read
- `[[routes]]` — one `custom_domain` entry per customer hostname

To find a firm UUID, query `PROD_DB.DBT_VERIFIED_TRANSFORM.TRANSFORM_FUND_ADMIN_FIRMS` (`ID`, by `CARTA_ID` or `NAME`).

## Deploy

```bash
cd plugins/carta-investors/skills/carta-manco-reporting
npx wrangler deploy
```

## Add a customer

1. Add the label and its firm UUID to `[vars].TENANTS`.
2. Add a route:

```toml
[[routes]]
pattern = "manco.<label>.carta.cloud"
custom_domain = true
```

3. `npx wrangler deploy`. Cloudflare provisions the DNS record and TLS certificate.

A hostname added outside wrangler still needs its `TENANTS` entry, or every firm is denied.

## Client budget upload

A firm's workbook budget reaches the hosted app as one JSON file, built locally by
`scripts/export_budget_bundle.py`. The Worker never parses a workbook.

- `POST /api/budget-upload` stores the bundle under `budget-bundle:<firm>` in KV, with no TTL.
  It needs `Content-Type: application/json`, a body under 4 MB, and a signed-in user Carta
  lets into the firm. It refuses a bundle whose `firm_uuid` is not that firm's, whose
  `schema_version` is not in `ACCEPTED_BUDGET_BUNDLE_SCHEMAS`, or that has no currency.
- `GET` returns what is stored (or `null`). `DELETE` removes it.
- `/api/snapshot` replaces `budget` and `varianceByCategory` with the bundle's and adds
  `budgetUpload` (who, when, `as_of`). A bundle in a different currency than the snapshot is
  left out and flagged `currency_mismatch`.

`SCHEMA_VERSION` in the exporter must always be in `server/worker.js`'s
`ACCEPTED_BUDGET_BUNDLE_SCHEMAS`, or an export can't be uploaded. Bumping
`BUDGET_BUNDLE_SCHEMA` means the exporter's own current output changes shape; add the old
value to `ACCEPTED_BUDGET_BUNDLE_SCHEMAS` alongside it so bundles exported by an
not-yet-updated plugin install still upload.

## Local development

Copy `wrangler.toml` to `wrangler.dev.toml`, drop every `[[routes]]` block, set
`workers_dev = false`, and run:

```bash
cd plugins/carta-investors/skills/carta-manco-reporting
npx wrangler dev --config wrangler.dev.toml
```

Dropping `[[routes]]` is what makes OAuth work. With routes present, `wrangler dev` serves the
*production* hostname, so the login redirect targets a production callback and the browser lands
on the deployed Worker. The state key only exists in local KV, so that fails with
"Invalid or expired state".

Serve over plain HTTP, not `--local-protocol https`. `mcp.app.carta.com` accepts
`http://localhost:…` because RFC 8252 exempts loopback addresses, and it rejects `http://` on a
public hostname — which is what the production hostname above produces.

`tenantOf()` returns null off `carta.cloud`, so local runs are unrestricted by tenant. Point
local runs at a non-production account and KV namespace.

`wrangler dev` needs the key too. Put a throwaway one in `.dev.vars` next to `wrangler.toml`
(gitignored):

```bash
echo "SESSION_KEY=$(openssl rand -base64 32)" > .dev.vars
```

## Troubleshooting

**403 "No access to firm"**: Either the label is missing from `TENANTS`, or the UUID in `TENANTS` is wrong,
or Carta refused `set_context` for that firm (the signed-in user is not staff and does not hold it).

**OAuth redirect loop**: The Worker uses dynamic client registration with `mcp.app.carta.com`.
Make sure the Worker URL matches the registered redirect URI (`https://<worker-url>/auth/callback`).

**"Unsupported schema_version N; expected ..." on upload**: The exporter (whatever plugin
version the user has installed) produced a bundle the *deployed* Worker doesn't recognize.
This is a deploy-lag symptom, not a code bug — check whether the Worker was redeployed after
the PR that last touched `BUDGET_BUNDLE_SCHEMA`/`ACCEPTED_BUDGET_BUNDLE_SCHEMAS` merged. Redeploy
with `npx wrangler deploy` (above); there is no other fix.

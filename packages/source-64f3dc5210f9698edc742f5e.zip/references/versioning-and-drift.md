# Versioning and Drift

## Naming Drift in Docs

The current Zoom docs are inconsistent about credential naming:
- AI Services auth page uses `API key` / `API secret`.
- Build-platform credentials page uses `SDK key` / `SDK secret`.
- Quickstart code uses `ZOOM_API_KEY` / `ZOOM_API_SECRET`.

Treat these as a portal/documentation naming drift issue and verify the current credential labels in the Zoom developer UI before changing production code.

## Product Positioning Drift

Scribe sits under `AI Services`, but related Zoom products may point users toward:
- RTMS for live meeting streams
- Meeting SDK Linux bots for visible in-meeting capture
- AI Services Summarizer for transcript recaps, summaries, and action items
- AI Services Translator for text translation/localization
- AI Companion / REST APIs for Zoom-generated summaries and transcripts
- blog or marketing material that frames Scribe inside broader speech/insights workflows

Keep the guardrail clear:
- `scribe` = generic live audio plus file/storage transcription service
- `summarizer` = transcript summarization service
- `translator` = plain-text translation service
- `rtms` = Zoom meeting-native audio/video/transcript/share/chat stream ingestion
- Meeting SDK Linux = participant bot capture / raw recording

## Workflow-Claim Drift

Some AI Services and Scribe blog material frames Scribe inside broader voice-insights workflows such as:
- post-call summaries
- ticket enrichment
- compliance logging
- searchable archives
- customer-support QA pipelines
- sentiment or keyword-driven downstream analytics

These are valid architectural use cases. Live audio transcription is now part of the documented
Scribe endpoint surface, but downstream analytics still require separate services or application
logic.

Implementation rule:
- use `scribe` for transcript generation
- use `summarizer` for transcript recap, summary, and action item workflows
- use `translator` for text localization workflows
- use your own downstream pipeline for sentiment, classification, or QA scoring
- use Scribe Live Mode only through its documented WebSocket protocol; do not infer additional analytics endpoints from blog phrasing

## API Surface Drift Watchpoints

Watch for changes in:
- storage providers beyond `S3`
- request field names in `config`
- webhook signature header conventions
- response summary/file schemas
- language / output-format support
- Live Mode event types, audio format requirements, session limits, and concurrency tiers

## Review Trigger

Re-review this skill when:
- `api-hub/ai-services/methods/endpoints.json` changes
- AI Services docs rename Build/API credentials again
- quickstart sample changes webhook or upload patterns
- Live Mode documentation or the quickstart relay protocol changes

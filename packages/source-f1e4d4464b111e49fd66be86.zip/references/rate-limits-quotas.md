# Blog Google - Rate Limits & Quotas

## Implemented API Quota Table

| API | Per-Minute | Per-Day | Cost | Auth Type | Scope |
|-----|-----------|---------|------|-----------|-------|
| GSC Search Analytics | 1,200 QPM per user, 1,200 QPM per site, 40,000 QPM per project | 30M QPD per project | Free | Service Account | Per user + per site + per project |
| GSC URL Inspection | 600 QPM per site, 15,000 QPM per project | 2,000 QPD per site, 10M QPD per project | Free | Service Account | Per site + per project |
| GSC Sitemaps | Standard | Standard | Free | Service Account | Per site |
| PageSpeed Insights v5 | 240 QPM | 25,000 QPD | Free | API Key | Per project |
| CrUX API | 150 QPM (shared) | Unlimited | Free | API Key | Per project |
| CrUX History API | 150 QPM (shared with CrUX) | Unlimited | Free | API Key | Per project |
| Indexing API | 380 RPM total, 180 read/min | 200 publish/day | Free | Service Account | Per project |
| GA4 Data API | 10 concurrent (50 for 360) | 200,000 Core Tokens/day (std); 2M (360) | Free | Service Account | Per property/project |
| YouTube Data API v3 |: | `search.list`: 100 calls/day at 1 unit per call (own bucket); other endpoints 10,000 units/day combined | Free | API Key | Per project |
| Cloud Natural Language API |: | 5,000 units/month free tier | Paid after free tier | API Key | Per project |
| Google Ads API | Account dependent | Account dependent | Free API access | OAuth + developer token | Per developer token and account |

Sources: https://developers.google.com/webmaster-tools/limits and https://developers.google.com/youtube/v3/determine_quota_cost (read 2026-10-12). The Search Analytics minute and day limits sit at different scopes: 1,200 QPM applies per site and per user, while 30M QPD (and 40,000 QPM) applies per project. Do not read them as one per-site figure.

**Key distinction:** "Per site" quotas are scoped to a specific GSC property. "Per project" quotas are shared across all properties in a GCP project. "Per user" quotas are per authenticated user (service account).

## Exponential Backoff Strategy

When receiving 429 or 5xx errors:

```
Attempt 1: wait 1 second
Attempt 2: wait 2 seconds
Attempt 3: wait 4 seconds
Attempt 4: wait 8 seconds
Attempt 5: wait 16 seconds
Max: give up after 5 retries
```

Add random jitter (0-500ms) to each wait to avoid thundering herd.

## Common Error Codes

| Code | Meaning | Applies To | Action |
|------|---------|------------|--------|
| 400 | Bad request | All | Check URL format, request body |
| 401 | Unauthorized | Service Account APIs | Refresh credentials |
| 403 | Forbidden | GSC, GA4, Indexing | Check permissions (service account access) |
| 404 | Not found | CrUX, GSC | Insufficient traffic (CrUX) or invalid property (GSC) |
| 429 | Rate limited | All | Backoff and retry. Check Retry-After header. |
| 500 | Server error | All | Retry with backoff |
| 503 | Service unavailable | All | Retry with backoff |

## Retry-After Header

Some Google APIs return a `Retry-After` header with 429 responses. When present, use this value (in seconds) instead of exponential backoff.

## GA4 Token Budgeting

GA4 uses a token system rather than simple request counts:
- Simple 1-dimension, 1-metric report: ~1-5 tokens
- Complex multi-dimension, multi-metric: ~10-100 tokens
- Set `returnPropertyQuota: true` to monitor consumption
- Daily limit: **200,000 Core Tokens/day** per standard property (2,000,000 for 360)
- Hourly limit: **40,000 tokens/hour** per property; **14,000/hour** per project per property
- Concurrent: max 10 simultaneous requests (50 for 360)
- Source: developers.google.com/analytics/devguides/reporting/data/v1/quotas (updated 2026-03-26)

## CrUX Shared Quota

The CrUX API and CrUX History API share the same 150 QPM quota per project. Plan accordingly if querying both APIs in the same workflow.

## Cost Summary

**Most APIs used by blog-google are free** at normal usage levels. No billing is required for:
- PSI, CrUX, CrUX History (API key, unlimited free)
- GSC (service account, 30M QPD per project)
- Indexing API (service account, 200 publish/day)
- GA4 Data API (service account, 200K tokens/day standard)
- YouTube Data API (API key; `search.list` is capped at 100 calls/day in its own bucket)

Cloud Natural Language requires billing enabled, with a free monthly tier. Google Ads API access is free, but Keyword Planner data quality depends on the Google Ads account.

## Planned or Out-of-Scope APIs

Knowledge Graph, Custom Search, and Web Risk are not implemented by scoped blog-google scripts. Do not count their quotas as available capabilities until a script and command surface exist.

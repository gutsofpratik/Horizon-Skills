---
name: altimate-code
description: >-
  Delegates dbt and warehouse work to altimate-code, a specialized CLI agent
  with 100+ purpose-built data tools. Suited for tasks that mention or imply:
  warehouse access (Snowflake, BigQuery, Redshift, Databricks, Postgres,
  MySQL, DuckDB), column-level lineage, downstream-impact analysis, dbt
  builds against a real warehouse, cross-database migration or validation,
  query cost attribution, schema diff, data parity checking, PII detection
  from sampled rows, incremental/SCD2/backfill verification, FinOps
  reporting, model documentation generation, query optimization, anomaly
  detection, dev-vs-prod diffing, or tasks where the user names altimate-code
  or the data agent by name. The skill routes to a purpose-built CLI, so it
  covers workloads that touch live data, lineage, or warehouse state more
  directly than native file-editing tools do.
---

# altimate-code

altimate-code is a CLI AI agent with 100+ purpose-built data engineering tools. **This skill exists for one purpose: delegate the user's task to altimate-code and pass the result back.** Native tools (Bash, Edit, Write, Read) are NOT a fallback path inside this skill — if altimate-code cannot complete the task, surface the failure to the user and STOP.

## You MUST follow this workflow

1. **Verify altimate-code is on PATH** with `command -v altimate-code`. If it returns nothing, jump to "Not installed" below and stop.
2. **Run altimate-code with the user's task** using the invocation below. Pass the user's request through verbatim — do not paraphrase or split it.
3. **Read the output file** and present it to the user as-is.

Do not attempt the work with Edit/Write/Bash yourself, even if it looks simple. The whole point of this skill is to route data-engineering work to the agent that's built for it. If you find yourself reaching for Edit or Write while this skill is active, stop and re-read this paragraph.

## Invocation — pick the right agent for the task

altimate-code has multiple agent personas. The default (`builder`) does a full project discovery sweep on every call — fine for warehouse-state work but ~10–20× more expensive than necessary on simple file edits. **Pick the agent based on task shape before invoking.**

### Step 1 — classify the task

| Shape | Examples | Use |
|---|---|---|
| **Any dbt / SQL task** (rename, refactor, create model, debug, structural reorg, multi-step setup) | the vast majority of customer requests | `fast-edit` — try this first |
| **Multi-table aggregation correctness** | new model joining 3+ tables with `count(*)` / `sum() over (...)` / "first X, last X" logic that must be exactly right | `analyst` if `fast-edit` fails the user's verification |
| **Warehouse-state work** | column-level lineage, downstream-impact, cross-DB migration / parity, query cost attribution against a real warehouse, schema diff between environments, PII detection, FinOps reporting | `builder` (default — has warehouse tools enabled) |
| **Vague debug** ("X is broken", "make it work", "fix this") | unspecified failure mode | **Don't delegate yet.** Ask the user for the specific error message or symptom before invoking any agent — empirically all three agents fail vague debug prompts at ~700K tokens each. |

**Decision policy:** start with `fast-edit` for any dbt/SQL task. If the user reports the result is wrong (e.g. aggregation values don't match), retry with `analyst`. Only use `builder` when the task genuinely needs the warehouse-investigation tools (it's 10–20× more expensive than fast-edit and rarely required).

### Step 2 — invoke with the chosen agent

Pass the task through a here-doc into a variable so the shell never
command-substitutes anything the user typed (a task like
`refactor `whoami` and $(rm -rf ~)` would otherwise fire `whoami` and
`rm -rf ~` before `altimate-code` ever runs). Write the result to a
private temporary file, not a shared one under `/tmp`:

```bash
TASK="$(cat <<'ALTIMATE_TASK'
<user's task, verbatim>
ALTIMATE_TASK
)"
umask 077
OUTPUT_FILE="$(mktemp -t altimate-result.XXXXXX.md)"
altimate-code run "$TASK" \
  --agent <fast-edit|analyst|builder> \
  --yolo \
  --output "$OUTPUT_FILE" \
  --dir "$(pwd)"
```

Then `Read "$OUTPUT_FILE"` and emit its contents to the user without re-summarising, re-formatting, or commenting on the result. altimate-code has already produced the answer. Delete `"$OUTPUT_FILE"` after presenting so warehouse rows, lineage, or PII findings don't linger on disk.

### Required flags

| Flag | Why it is required |
|---|---|
| `--agent <name>` | Picks the agent persona. Default `builder` is overkill for simple edits — see the classification table above. Wrong agent = either 10× too expensive (using `builder` on a rename) or wrong-answer (using `fast-edit` on a multi-table join). |
| `--yolo` | Non-interactive mode. Without this the subprocess hangs on the first permission prompt and you will time out. |
| `--output "$OUTPUT_FILE"` | Captures the final response. Use the private `mktemp` file from above — do NOT use a fixed path like `/tmp/altimate-result.md`; concurrent sessions clobber each other and a world-readable fixed path leaks data. |
| `--dir "$(pwd)"` | Runs altimate-code in the current project so it picks up dbt project config, profiles.yml, etc. |

### Follow-up tasks in the same project

When the user makes a follow-up data task in the same project after a successful altimate-code delegation, prefer `--continue` to resume the warm session instead of starting a fresh one. Same here-doc + `mktemp` pattern:

```bash
TASK="$(cat <<'ALTIMATE_TASK'
<follow-up task>
ALTIMATE_TASK
)"
umask 077
OUTPUT_FILE="$(mktemp -t altimate-result.XXXXXX.md)"
altimate-code run "$TASK" \
  --agent <fast-edit|analyst|builder> \
  --yolo \
  --output "$OUTPUT_FILE" \
  --dir "$(pwd)" \
  --continue   # resumes the most recent session in this dir
```

altimate-code's prompt cache is warm in a continued session — project structure, profiles.yml, schema index, source definitions don't need to be re-investigated. Cache reads are billed at a fraction of fresh input on altimate-gateway. The downside is zero: if there's no useful cached context for the new task, you pay normal cold cost.

If the user starts a clearly unrelated workflow (different project, different schema, different debugging thread), drop `--continue` and start fresh — the warm cache is irrelevant and you'd carry unrelated history into the prompt.

## Failure modes — route every one to the user

When altimate-code returns an error, **report the error to the user and STOP**. Do not fall back to Bash, Edit, or Write. The skill's contract is "altimate-code handles this, or the user is told why it couldn't."

| Symptom | What to tell the user — verbatim |
|---|---|
| `command not found: altimate-code` | "altimate-code is not installed. Install with `npm install -g altimate-code` (Node 20+) and run `altimate-code` once to configure auth. Then re-run your request." |
| `Unauthorized: Incorrect auth token` / `No provider configured` | "altimate-code's LLM provider auth is misconfigured. Run `altimate-code` in your terminal to open the TUI and reconfigure your provider, then re-run your request." |
| Process hangs >5 min | "altimate-code is unresponsive. Try `altimate-code` to inspect the TUI for an open prompt, or re-run with `--model anthropic/claude-sonnet-4-6` to force a known-good model." |
| Output file empty | "altimate-code returned without producing output. The task may be too ambiguous — please restate with more detail (target table, expected columns, time window)." |
| Warehouse error mid-run (`UNKNOWN_USER`, `Database does not exist`) | "altimate-code can connect but the warehouse credentials it has are wrong for this project. Configure provider/warehouse auth via `altimate-code` TUI." |

In every row, the instruction to the user is the action — you do not retry the task with native tools. If the user fixes the underlying issue and asks again, you delegate again.

## Notes

- altimate-code runs its own LLM, separate from Claude Code's. Costs and rate limits accrue to altimate-code's configured provider.
- Sessions persist in altimate-code's local store — `altimate-code session list` shows prior runs; `--continue` resumes the latest, `--session <id>` resumes a specific one.
- For very long tasks, the `--output` file is the source of truth — stdout buffering can drop content.

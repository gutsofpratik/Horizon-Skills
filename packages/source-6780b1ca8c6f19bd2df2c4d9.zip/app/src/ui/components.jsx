// Shared UI kit — Ink component recipes, one implementation each.
//
// Values are copied from skill-dev:theme-with-ink's `components.md`, which is a
// mechanical port of Ink's real rendered CSS. They are not approximations and not
// re-derived from a screenshot: where a number appears here it is the literal value in
// that file (40px field height, 0 12px padding, 14px/weight-400 text,
// border-default at rest, border-hover on hover, and the two-part focus recipe).
//
// theme-with-ink itself cannot theme this app — its contract is vanilla-only, no React
// and no CSS-in-JS. So this file ports its recipes into the styling model the app
// actually uses, which is what build-micro-app's retrofit mode is for.
//
// Before this existed, each view hand-rolled its own controls: four <select>s sharing a
// copy-pasted `padding: "5px 8px"` and no appearance reset, so they rendered ~30px tall
// with OS chrome and did not match Ink's 40px fields sitting next to them.

import { createContext, useCallback, useContext, useEffect, useLayoutEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { C, FS, RADIUS, SANS, SHADOW } from "./theme.js";

/** Ink's chevron-down. Static: this app's menus only ever open downward.
 *
 *  `stroke` is set via the style prop rather than the SVG presentation attribute —
 *  Safari < 15.4 silently ignores a var() reference in a presentation attribute and
 *  falls back to `none`, rendering nothing.
 */
export function ChevronDown({ size = 16 }) {
  return (
    <svg
      width={size} height={size} viewBox="0 0 24 24" fill="none"
      strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round"
      style={{ stroke: "currentColor", flex: "0 0 auto" }}
      aria-hidden
    >
      <path d="M6 9l6 6 6-6" />
    </svg>
  );
}

/** Marks a value this console derived or edited, rather than one Carta returned. */
export function SparkleAI({ size = 14, title }) {
  const [anchor, setAnchor] = useState(null);
  const hide = useCallback(() => setAnchor(null), []);
  return (
    <span
      style={{ position: "relative", display: "inline-flex", alignItems: "center", justifyContent: "center", flex: "0 0 auto" }}
      onMouseEnter={title ? (e) => setAnchor(e.currentTarget.getBoundingClientRect()) : undefined}
      onMouseLeave={title ? hide : undefined}
    >
      <span style={{
        display: "inline-flex", alignItems: "center", justifyContent: "center",
        background: "#FFF7F5", borderRadius: "9999px", padding: 3,
      }}>
        <svg
          width={size} height={size} viewBox="0 0 24 24" fill="none"
          stroke="#E8704C" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"
          style={{ display: "block" }} aria-hidden
        >
          <path d="M2 21a8 8 0 0 1 10.821-7.487" />
          <path d="M21.378 16.626a1 1 0 0 0-3.004-3.004l-4.01 4.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z" />
          <circle cx="10" cy="8" r="5" />
        </svg>
      </span>
      {anchor && title && <Tooltip anchor={anchor} onHide={hide}>{title}</Tooltip>}
    </span>
  );
}

const TIP_GAP = 6;
const TIP_MARGIN = 8;

/** Portalled to <body> so no `overflow` ancestor (a table cell, a scroll wrapper) can
 *  clip it, and clamped to the viewport so an icon near an edge doesn't push it off.
 */
function Tooltip({ anchor, onHide, children }) {
  const ref = useRef(null);
  const [pos, setPos] = useState(null);

  useLayoutEffect(() => {
    const { width, height } = ref.current.getBoundingClientRect();
    const centred = anchor.left + anchor.width / 2 - width / 2;
    const left = Math.max(TIP_MARGIN, Math.min(centred, window.innerWidth - width - TIP_MARGIN));
    const above = anchor.top - height - TIP_GAP;
    setPos({ left, top: above >= TIP_MARGIN ? above : anchor.bottom + TIP_GAP });
  }, [anchor]);

  // Fixed position doesn't follow a scrolling container, so close instead of drifting.
  useEffect(() => {
    window.addEventListener("scroll", onHide, true);
    return () => window.removeEventListener("scroll", onHide, true);
  }, [onHide]);

  return createPortal(
    <span ref={ref} role="tooltip" style={{
      position: "fixed", left: pos?.left ?? 0, top: pos?.top ?? 0,
      visibility: pos ? "visible" : "hidden",
      background: C.surfaceDefault, color: C.textDefault, border: `1px solid ${C.borderDefault}`,
      borderRadius: 6, padding: "4px 8px", fontSize: FS.xs, whiteSpace: "nowrap",
      pointerEvents: "none", zIndex: 1000,
      boxShadow: "0 2px 8px rgba(0,0,0,.12)",
    }}>
      {children}
    </span>,
    document.body,
  );
}

/** A labelled select following Ink's field recipe.
 *
 *  Native <select> for the menu itself: it is keyboard-accessible, screen-reader
 *  correct and scroll-aware for free. Ink's own `.ink-menu` recipe is for a custom
 *  anchored menu built with JS — reimplementing that here would trade all of the above
 *  for a visual detail nobody asked for. The FIELD is what was wrong, so the field is
 *  what this fixes: 40px, appearance:none, and our own chevron.
 */
/** Consecutive options sharing a `group` become one <optgroup>; ungrouped ones
 *  render bare, so existing callers are unchanged. */
export function optionGroups(options) {
  const out = [];
  for (const o of options) {
    const last = out[out.length - 1];
    if (last && last.group === (o.group || null)) last.options.push(o);
    else out.push({ group: o.group || null, options: [o] });
  }
  return out;
}

export function Select({
  label, value, onChange, options, hint, minWidth = 0, maxWidth, icon, disabled,
}) {
  const [hover, setHover] = useState(false);
  const [focus, setFocus] = useState(false);

  return (
    <label style={{ display: "inline-flex", flexDirection: "column", gap: 4 }}>
      {label && (
        // `icon` sits OUTSIDE the truncating span on purpose: ellipsis needs a
        // text node to clip, and an icon inside would be clipped away first on a
        // long label — losing the one part that marks what kind of filter this is.
        <span style={{
          display: "inline-flex", alignItems: "center", gap: 5,
          fontSize: FS.sm, color: C.textSubtle,
          ...(maxWidth ? { maxWidth } : null),
        }}>
          {icon}
          <span style={maxWidth ? {
            // Bounded when maxWidth is set: a label that is DATA (a Claude
            // filter's own name) can run long, and the label is what would
            // stretch the control rather than the options inside it.
            minWidth: 0, overflow: "hidden",
            textOverflow: "ellipsis", whiteSpace: "nowrap",
          } : undefined}>{label}</span>
        </span>
      )}
      <span
        style={{ position: "relative", display: "inline-flex", alignItems: "center" }}
        onMouseEnter={() => setHover(true)}
        onMouseLeave={() => setHover(false)}
      >
        <select
          value={value}
          onChange={(e) => onChange(e.target.value)}
          title={hint}
          disabled={disabled}
          onFocus={() => setFocus(true)}
          onBlur={() => setFocus(false)}
          style={{
            // Ink .ink-input: 40px tall, 0 12px padding, 14px/400.
            height: 40,
            // Extra right padding leaves room for the chevron overlaid below.
            padding: "0 34px 0 12px",
            minWidth,
            // Optional, for a label whose text is data rather than a fixed option
            // name — a Claude filter's own sentence, say. The native control has
            // no ellipsis of its own, so without a bound one long value stretches
            // the row it sits in.
            maxWidth,
            textOverflow: maxWidth ? "ellipsis" : undefined,
            font: `400 ${FS.md}px/1 ${SANS}`,
            color: disabled ? C.textQuiet : C.textDefault,
            background: disabled ? C.surfaceUnderlay : C.surfaceDefault,
            border: `1px solid ${focus ? C.linkDefault : hover ? C.borderHover : C.borderDefault}`,
            borderRadius: RADIUS,
            // The OS chrome is what made these look foreign next to Ink's fields.
            appearance: "none",
            WebkitAppearance: "none",
            // Ink's two-part focus: recolor the border AND add a 4px pale-blue ring.
            boxShadow: focus ? `0 0 0 4px ${C.focusRing}` : "none",
            outline: "none",
            cursor: disabled ? "not-allowed" : "pointer",
          }}
        >
          {optionGroups(options).map((g) => (g.group
            ? (
              <optgroup key={g.group} label={g.group}>
                {g.options.map((o) => (
                  <option key={o.value} value={o.value} disabled={o.disabled}>{o.label}</option>
                ))}
              </optgroup>
            )
            : g.options.map((o) => (
              <option key={o.value} value={o.value} disabled={o.disabled}>{o.label}</option>
            ))))}
        </select>
        {/* Overlaid, not a sibling: keeps the control one hit target, and pointer-events
            none lets the click fall through to the select underneath. */}
        <span style={{
          position: "absolute", right: 11, display: "inline-flex",
          pointerEvents: "none", color: C.textSubtle,
        }}>
          <ChevronDown />
        </span>
      </span>
    </label>
  );
}

/** Ink's Tag — regular weight (400), tone-matched border, radius-subtle, sentence case.
 *
 *  The border carries the SEMANTIC TONE rather than a shared neutral gray, and the
 *  weight stays 400: bolding a status label is the most common drift away from this
 *  recipe. Height is left to content — Ink fixes standalone badges at 28px, but a dense
 *  table row needs to be more compact than that assumes.
 */
export const TAG_TONES = {
  neutral: { fg: C.textSubtle, bd: C.borderDefault, bg: C.surfaceUnderlay },
  info: { fg: C.linkDefault, bd: C.linkDefault, bg: C.infoSubtle },
  positive: { fg: C.feedbackPositive, bd: C.feedbackPositive, bg: C.positiveSubtle },
  negative: { fg: C.feedbackNegative, bd: C.feedbackNegative, bg: C.surfaceUnderlay },
  notice: { fg: C.feedbackNotice, bd: C.feedbackNotice, bg: C.feedbackNoticeSubtle },
};

// `pill` is a compact, fully-rounded variant for a badge sitting under its own
// label rather than inline with text — e.g. a header's "Estimated" marker.
export function Tag({ tone = "neutral", pill = false, children, title }) {
  const t = TAG_TONES[tone] || TAG_TONES.neutral;
  return (
    <span
      title={title}
      style={{
        display: pill ? "inline-flex" : "inline-block",
        alignItems: "center", justifyContent: "center",
        height: pill ? 18 : undefined,
        padding: pill ? "2px 8px" : "1px 7px",
        borderRadius: pill ? 999 : RADIUS,
        fontSize: FS.sm, fontWeight: pill ? 500 : 400,
        lineHeight: pill ? "12px" : undefined,
        letterSpacing: pill ? "0.255px" : undefined,
        whiteSpace: "nowrap",
        color: t.fg, background: t.bg, border: `1px solid ${t.bd}`,
      }}
    >
      {children}
    </span>
  );
}

// A table can set one alignment for every cell inside it, instead of every Th/Td
// repeating the same `align`. Used by the Scorecard, where all twelve columns are
// centred; Benchmarks passes `align` per cell and is unaffected.
//
// Deliberately a context rather than a new default: flipping the default would silently
// re-align every existing table, including ones whose right-aligned money columns are
// right-aligned on purpose.
const AlignContext = createContext(null);

export function TableAlign({ align, children }) {
  return <AlignContext.Provider value={align}>{children}</AlignContext.Provider>;
}

/** Ink's table header cell: sentence case, 14px/weight-500, full-contrast text, with a
 *  border-default (medium gray) under-rule — clearly darker than the hairline between
 *  body rows, nowhere near the near-black text color. Deliberately NOT the
 *  uppercase/tracked/tiny "ledger" look, which Ink drops. */
export function Th({ children, align, valign, width, colSpan, group, tinted }) {
  const ctx = useContext(AlignContext);
  // Explicit prop wins, then the table-wide value, then the historical default.
  align = align || ctx || "left";
  return (
    <th
      colSpan={colSpan}
      style={{
        padding: "8px 10px", fontSize: FS.md, fontWeight: 500, color: C.textDefault,
        textAlign: align, verticalAlign: valign, whiteSpace: "nowrap", width,
        // A `group` heading spans several columns above the real ones, so it takes the
        // hairline: the darker under-rule belongs on the row that actually labels the
        // columns, or the table reads as having two competing header baselines.
        borderBottom: `1px solid ${group ? C.borderSubtle : C.borderDefault}`,
        background: tinted ? C.surfaceTinted : undefined,
      }}
    >{children}</th>
  );
}

/** Ink's table body cell: 14px/weight-400, border-subtle hairline between rows. */
export function Td({ children, align, valign, subtle, mono, ellipsis, title, tinted }) {
  const ctx = useContext(AlignContext);
  align = align || ctx || "left";
  return (
    <td title={title} style={{
      padding: "7px 10px", fontSize: FS.md, fontWeight: 400, textAlign: align,
      verticalAlign: valign,
      color: subtle ? C.textQuiet : C.textDefault,
      fontVariantNumeric: mono ? "tabular-nums" : undefined,
      borderBottom: `1px solid ${C.borderSubtle}`, whiteSpace: "nowrap",
      background: tinted ? C.surfaceTinted : undefined,
      ...(ellipsis ? { overflow: "hidden", textOverflow: "ellipsis" } : null),
    }}>{children}</td>
  );
}

/** Multi-select in a dropdown: the same 40px field as `Select`, opening a checkbox list.
 *
 *  NOT a native <select multiple>. Native wins everywhere else in this kit — it brings
 *  keyboard, screen-reader and scroll behaviour for free — but that trade stops paying for
 *  multi-select: it needs ctrl/cmd-click to add a second item, drops the whole selection on
 *  a plain click, and shows about four of 22 rows at a time. Losing a selection you spent
 *  six clicks building is worse than any styling detail.
 *
 *  So the FIELD borrows Select's recipe exactly (40px, 0 12px padding, overlaid chevron,
 *  two-part focus) and the menu is a real checkbox list. Options are <label><input
 *  type=checkbox> — the platform gives each row a hit target, a tab stop and the
 *  checked-state announcement, none of which a div-and-aria reimplementation gets right
 *  for free.
 *
 *  `selected` is a Set of codes. Empty means "all" to the CALLER; this component only
 *  reports what was clicked, which keeps "no filter" and "everything ticked" from needing
 *  to be told apart here.
 */
export function MultiSelect({
  label, options, selected, onToggle, onAll, allLabel, minWidth = 0, icon,
}) {
  const [open, setOpen] = useState(false);
  const [hover, setHover] = useState(false);
  const [focus, setFocus] = useState(false);
  const wrapRef = useRef(null);

  // Close on outside click and on Escape. Without the outside-click half, the menu stays
  // open behind whatever the user clicks next and covers the grid it is filtering.
  useEffect(() => {
    if (!open) return undefined;
    const onDown = (e) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target)) setOpen(false);
    };
    const onKey = (e) => { if (e.key === "Escape") setOpen(false); };
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  const n = selected.size;
  const noun = label ? label.toLowerCase() : "options";
  // The field reads as a summary, not a list: 22 comma-joined labels would overflow any
  // sane width, and truncating them mid-name reads as data loss.
  const summary = n === 0
    ? allLabel
    : n === 1
      ? (options.find((o) => o.value === [...selected][0]) || {}).label || `${n} selected`
      : `${n} of ${options.length} selected`;

  return (
    <span
      ref={wrapRef}
      style={{ display: "inline-flex", flexDirection: "column", gap: 4, position: "relative" }}
    >
      {label && (
        <span style={{
          display: "inline-flex", alignItems: "center", gap: 5,
          fontSize: FS.sm, color: C.textSubtle,
        }}>
          {icon}
          <span>{label}</span>
        </span>
      )}
      <span
        style={{ position: "relative", display: "inline-flex", alignItems: "center" }}
        onMouseEnter={() => setHover(true)}
        onMouseLeave={() => setHover(false)}
      >
        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          onFocus={() => setFocus(true)}
          onBlur={() => setFocus(false)}
          aria-expanded={open}
          aria-haspopup="true"
          title={n ? `${n} of ${options.length} ${noun} shown` : `All ${noun} shown`}
          style={{
            height: 40,
            padding: "0 34px 0 12px",
            minWidth,
            font: `400 ${FS.md}px/1 ${SANS}`,
            color: C.textDefault,
            background: C.surfaceDefault,
            border: `1px solid ${focus || open ? C.linkDefault : hover ? C.borderHover : C.borderDefault}`,
            borderRadius: RADIUS,
            boxShadow: focus ? `0 0 0 4px ${C.focusRing}` : "none",
            outline: "none",
            cursor: "pointer",
            textAlign: "left",
            whiteSpace: "nowrap",
          }}
        >
          {summary}
        </button>
        <span style={{
          position: "absolute", right: 11, display: "inline-flex",
          pointerEvents: "none", color: C.textSubtle,
        }}>
          <ChevronDown />
        </span>
      </span>

      {open && (
        <div
          role="group"
          aria-label={label}
          style={{
            position: "absolute", top: "100%", left: 0, marginTop: 4, zIndex: 20,
            minWidth: 220, maxHeight: 320, overflowY: "auto",
            background: C.surfaceDefault,
            border: `1px solid ${C.borderDefault}`,
            borderRadius: RADIUS,
            // Ink's shadow-medium, as .ink-menu calls for. Was a hand-written
            // rgba() that no dark-mode surface adapts with.
            boxShadow: SHADOW.medium,
            padding: 4,
          }}
        >
          <button
            type="button"
            onClick={() => { onAll(); }}
            style={{
              display: "block", width: "100%", textAlign: "left",
              font: `400 ${FS.sm}px/1.4 ${SANS}`,
              color: n === 0 ? C.linkDefault : C.textSubtle,
              background: "transparent", border: "none", borderRadius: RADIUS,
              padding: "6px 8px", cursor: "pointer",
            }}
          >
            {allLabel}
          </button>
          <span style={{
            display: "block", height: 1, background: C.borderSubtle, margin: "4px 0",
          }} />
          {options.map((o) => (
            <label
              key={o.value}
              style={{
                display: "flex", alignItems: "center", gap: 8,
                padding: "6px 8px", borderRadius: RADIUS, cursor: "pointer",
                font: `400 ${FS.sm}px/1.4 ${SANS}`, color: C.textDefault,
                whiteSpace: "nowrap",
              }}
            >
              <input
                type="checkbox"
                checked={selected.has(o.value)}
                onChange={() => onToggle(o.value)}
                style={{ margin: 0, cursor: "pointer" }}
              />
              {o.label}
            </label>
          ))}
        </div>
      )}
    </span>
  );
}

/** A "more actions" menu behind a single trigger.
 *
 *  For a group of occasional actions that should not sit permanently at the same
 *  visual weight as the one people actually reach for — and, when one of them is
 *  destructive, should take a deliberate extra step to reach.
 *
 *  `items` are `{ label, onSelect, title, disabled, separated, trailing }`.
 *  `separated` draws Ink's rule above the item, for a genuine group break;
 *  `trailing` is an optional right-pinned node (a Tag, say); `disabled` keeps the
 *  item VISIBLE with its reason on the control, rather than hiding it, so "why
 *  can't I delete this?" has an answer on screen.
 *
 *  There is deliberately NO danger variant, because Ink's DropdownItem has none —
 *  see the note in MenuItem.
 *
 *  Dismissal is MultiSelect's, deliberately: outside-click and Escape, with the
 *  listeners bound only while open. A menu that survives the next click covers the
 *  thing it was opened from.
 */
/** One row of a Menu. Its own component because hover and active are per-item
 *  state, and Ink's .ink-menu__item specifies both — a menu that does not tint
 *  under the cursor reads as a static list, and one that does not darken on press
 *  feels unresponsive at the moment of clicking.
 *
 *  A disabled item takes NEITHER tint: it is on screen to explain why it cannot be
 *  used, not to invite the click.
 */
function MenuItem({ item, onRun }) {
  const [hover, setHover] = useState(false);
  const [active, setActive] = useState(false);
  const tint = item.disabled ? "transparent"
    : active ? C.menuItemActive : hover ? C.menuItemHover : "transparent";
  return (
    <button
      type="button"
      role="menuitem"
      disabled={item.disabled}
      title={item.title}
      onClick={onRun}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => { setHover(false); setActive(false); }}
      onMouseDown={() => setActive(true)}
      onMouseUp={() => setActive(false)}
      style={{
        // Ink's DropdownItem, value for value: 6px/12px, body-3 (14px/24px),
        // text-default, full width.
        //
        // A FLEX ROW with space-between rather than a block of text — that is what
        // lets an item carry a trailing badge ("New", "Staff") pinned to the right
        // edge, as Carta's own overflow menus do. Nothing here uses one yet; the
        // layout is Ink's, so one can be added without restyling the item.
        display: "flex", alignItems: "baseline", justifyContent: "space-between",
        width: "100%", textAlign: "left",
        font: `400 ${FS.md}px/24px ${SANS}`,
        // NO danger colour. Ink's DropdownItem has no destructive variant at all —
        // Carta's own menus render "Terminate stakeholder" in the same text-default
        // as everything around it, and let the confirm dialog carry the weight. A
        // red item here would be this console inventing a convention.
        color: item.disabled ? C.textDisabled : C.textDefault,
        background: tint,
        border: "none", borderRadius: 0,
        padding: "6px 12px",
        cursor: item.disabled ? "not-allowed" : "pointer",
        whiteSpace: "nowrap",
      }}
    >
      <span>{item.label}</span>
      {item.trailing}
    </button>
  );
}

export function Menu({ label = "More actions", items, align = "left" }) {
  const [open, setOpen] = useState(false);
  const [hover, setHover] = useState(false);
  const [focus, setFocus] = useState(false);
  const wrapRef = useRef(null);

  useEffect(() => {
    if (!open) return undefined;
    const onDown = (e) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target)) setOpen(false);
    };
    const onKey = (e) => { if (e.key === "Escape") setOpen(false); };
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  return (
    <span ref={wrapRef} style={{ position: "relative", display: "inline-flex" }}>
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        onFocus={() => setFocus(true)}
        onBlur={() => setFocus(false)}
        onMouseEnter={() => setHover(true)}
        onMouseLeave={() => setHover(false)}
        aria-expanded={open}
        aria-haspopup="menu"
        // An icon-only trigger is guessed at until hovered, so it carries a real
        // accessible name rather than leaving screen readers with the glyph.
        aria-label={label}
        title={label}
        style={{
          height: 40, width: 40, padding: 0,
          font: `500 ${FS.md}px/1 ${SANS}`,
          color: C.textDefault, background: C.surfaceDefault,
          border: `1px solid ${focus || open ? C.linkDefault : hover ? C.borderHover : C.borderDefault}`,
          borderRadius: RADIUS,
          boxShadow: focus ? `0 0 0 4px ${C.focusRing}` : "none",
          outline: "none", cursor: "pointer", letterSpacing: "0.08em",
        }}
      >
        ···
      </button>

      {open && (
        // Ink's DropdownBox, value for value from ink-inputs: border-subtle,
        // radius-subtle, shadow-SMALL (the menu floats close to its trigger; medium
        // is for surfaces that sit further off the page), 2px off the trigger, and
        // 6px of padding on the block axis only — items run the full width so their
        // hover tint reaches the surface edge.
        <div
          role="menu"
          aria-label={label}
          style={{
            position: "absolute", top: "100%", marginTop: 2, zIndex: 20,
            [align === "right" ? "right" : "left"]: 0,
            minWidth: 200,
            background: C.surfaceDefault,
            border: `1px solid ${C.borderSubtle}`,
            borderRadius: RADIUS,
            boxShadow: SHADOW.small,
            padding: "6px 0",
          }}
        >
          {items.map((item, i) => (
            <span key={item.label}>
              {/* Ink's DropdownSeparator: border-default at 1px with 4px above and
                  below. Opt-in per item rather than implied by anything, since the
                  real component separates GROUPS, not "the dangerous one". */}
              {item.separated && i > 0 && (
                <span style={{
                  display: "block", height: 1, background: C.borderDefault, margin: "4px 0",
                }} />
              )}
              <MenuItem item={item} onRun={() => { setOpen(false); item.onSelect(); }} />
            </span>
          ))}
        </div>
      )}
    </span>
  );
}

/** True when the viewport matches `query`. Re-renders on change.
 *
 *  This file styles inline rather than through a stylesheet, so a plain CSS media
 *  query is not available for layout that must actually reflow. Guarded for
 *  environments without matchMedia (happy-dom under test), where it reports false
 *  and callers fall back to the narrow, stacked layout — the safe direction, since
 *  stacking hides nothing.
 */
export function useMediaQuery(query) {
  const get = () =>
    typeof window !== "undefined"
    && typeof window.matchMedia === "function"
    && window.matchMedia(query).matches;

  const [matches, setMatches] = useState(get);

  useEffect(() => {
    if (typeof window === "undefined" || typeof window.matchMedia !== "function") return;
    const mql = window.matchMedia(query);
    const onChange = () => setMatches(mql.matches);
    onChange();
    mql.addEventListener("change", onChange);
    return () => mql.removeEventListener("change", onChange);
  }, [query]);

  return matches;
}

---
name: platform-custom-application-generate
description: "Use this skill when users need to create or configure tab-based Salesforce Custom Applications with navigation, branding, and action overrides. Trigger when users mention custom apps, application metadata, app navigation, or organizing tabs into applications. Use when users want to create app containers for tabs and pages. Do NOT use when the goal is hosting a React UI bundle in the App Launcher — use experience-ui-bundle-custom-app-generate for that case."
metadata:
  version: "1.0"
  domains: ["Platform"]
  minApiVersion: "60.0"
  relatedSkills:
    - "experience-ui-bundle-custom-app-generate"
---

## When to Use This Skill

Use this skill when you need to:
- Create Lightning applications
- Organize tabs and features into focused apps
- Configure application navigation and branding
- Set up custom page layouts for objects
- Troubleshoot deployment errors related to custom applications
# CustomApplication (Lightning App) Metadata Specification

## Overview

Custom applications (Lightning Apps) that group tabs and functionality to provide a focused user experience for specific business processes. Always configured for Lightning Experience.

## Purpose
- Organize related functionality into focused applications
- Group tabs and components for specific user roles
- Provide tailored user experiences
- Control access to specific features and data
- Use Standard navigation for general business applications or Console navigation for specialized service/support workflows requiring multi-tab workspaces
- Create professional, branded application identity with custom colors and branding
- Override standard actions with custom Lightning pages for enhanced user experience
- Enable profile-specific experiences through profile action overrides

## Required Properties

### Core Application Properties
- **fullName**: API name of the application
- **label**: Display name of the application
- **uiType**: Always "Lightning" for modern apps
- **navType**: CRITICAL - Choose based on user requirements and workflow patterns
    - "Standard": DEFAULT for general business applications (e.g., sales, marketing, operations)
    - "Console": ONLY when workflow requires managing multiple records simultaneously with split-view or multi-tab workspace (e.g., customer service, call centers, support operations)
- **formFactors**: Array of form factors (["LARGE"] for desktop, ["SMALL"] for mobile, or both)

### Optional Properties
- **description**: Brief description of the application's purpose
- **tabs**: Array of tab names to include
- **utilityBar**: API name of the Utility Bar configuration
- **brand**: HIGHLY RECOMMENDED - Branding configuration object (headerColor, shouldOverrideOrgTheme, footerColor)
- **actionOverrides**: REQUIRED when custom record pages exist - Action override configuration (actionName, content, formFactor, type, pageOrSobjectType)
- **profileActionOverrides**: Profile-specific action overrides (actionName, content, formFactor, pageOrSobjectType, type, profile)
- **isNavAutoTempTabsDisabled**: Navigation behavior setting (default: false)
- **isNavPersonalizationDisabled**: Personalization setting (default: false)
- **isNavTabPersistenceDisabled**: Tab persistence setting (default: false)

## Application Configuration

### Navigation Type Selection (CRITICAL)
**Decision Criteria for navType:**

**Choose "Standard" (DEFAULT) for:**
- General business applications and most workflows
- Single-record focus or linear navigation patterns
- Standard tab-based navigation is sufficient

**Choose "Console" ONLY when workflow requires:**
- Managing multiple related records simultaneously in split-view
- Multi-tab workspace for handling complex, interconnected data
- Contextual information from multiple sources visible at once
- Examples: customer service operations, support desks, call centers

**When in doubt:** Default to "Standard" for most general business use cases

### Navigation Settings
- **isNavAutoTempTabsDisabled**: Controls automatic temporary tab creation
- **isNavPersonalizationDisabled**: Controls user personalization features
- **isNavTabPersistenceDisabled**: Controls tab persistence across sessions

### Tab Management
- **tabs**: Array of tab names to include in the application
- **formFactors**: Device-specific configurations (Large for desktop, Small for mobile)

### Utility Bar
- **utilityBar**: Reference to Lightning utility bar (appears at bottom of Lightning Experience)

### Branding (HIGHLY RECOMMENDED - DO NOT SKIP)
**IMPORTANT**: Provide branding configuration to create a professional, visually distinct application identity.

- **brand.headerColor**: Header bar color in hex format (e.g., "#0070D2") - RECOMMENDED
- **brand.shouldOverrideOrgTheme**: Override organization theme (true/false) - Default: false
- **brand.footerColor**: Footer color in hex format

### Action Overrides (CRITICAL - DO NOT SKIP)
**IMPORTANT**: Action overrides MUST be created for every custom object tab that has a record page generated by flexipage expert.

- **actionOverrides.actionName**: Action to override ("View" or "Tab")
- **actionOverrides.content**: Page/component name (FlexiPage, Visualforce, Lightning component)
    - For "View" action: Reference record pages generated by flexipage expert
    - For "Tab" action: Reference home/app pages generated by flexipage expert
- **actionOverrides.formFactor**: Device type ("Large" or "Small")
- **actionOverrides.type**: Override type ("Default", "Visualforce", "Flexipage", "LightningComponent", "Scontrol")
    - Recommended: Use "Flexipage" for Lightning record/home pages generated by flexipage expert
- **actionOverrides.pageOrSobjectType**: Object API name the override applies to
- **actionOverrides.comment**: Optional description (max 1000 characters)
    - Auto-generated comment: "Action override created by Lightning App Builder during activation."
- **actionOverrides.skipRecordTypeSelect**: Skip record type selection (default: false)

### Profile Action Overrides
- **profileActionOverrides.actionName**: Action to override ("View" or "Tab")
- **profileActionOverrides.content**: Page/component name
    - For "View" action: Reference profile-specific record pages generated by flexipage expert
    - For "Tab" action: Reference profile-specific home pages generated by flexipage expert
    - Can reference same or different FlexiPages than actionOverrides for profile-specific experiences
- **profileActionOverrides.formFactor**: Device type ("Large" or "Small")
- **profileActionOverrides.pageOrSobjectType**: Object API name
- **profileActionOverrides.type**: Override type
    - Recommended: Use "Flexipage" for Lightning pages generated by flexipage expert
- **profileActionOverrides.profile**: Profile API name (e.g., "Admin", "Standard User")
    - Enables different page layouts for different user profiles

## Device Support

### Desktop Configuration
- **formFactor**: "Large"
- **tabs**: Full list of application tabs

### Phone Configuration
- **formFactor**: "Small"
- **tabs**: Mobile-optimized tab selection

### Tablet Configuration
- **formFactor**: "Medium"
- **tabs**: Tablet-appropriate tab selection

## User Experience Features

### Navigation Behavior
- **Auto Temporary Tabs**: Can be enabled/disabled
- **Personalization**: User customization options
- **Tab Persistence**: Remember user's tab selections

### Accessibility
- **Keyboard Navigation**: Full keyboard support
- **Screen Reader**: Compatible with assistive technologies
- **High Contrast**: Support for high contrast modes

## Integration Points
- **Custom Tabs**: Include custom object and web tabs
- **Standard Tabs**: Include standard Salesforce tabs
- **Lightning Pages**: Integrate with Lightning page layouts
- **Components**: Include custom Lightning components
## Best Practices
- **Always use Lightning UI**: Set `uiType` to "Lightning" for modern apps
- **Choose appropriate navigation**: CRITICAL - Analyze requirements carefully for `navType` selection
    - Use "Standard" (DEFAULT) for general business applications
    - Use "Console" ONLY when workflow requires multi-tab workspace, split-view, or managing multiple related records simultaneously
    - Examples for Console: customer service, call centers, support operations
    - Default to "Standard" for most general business use cases
- **Include Standard Tabs**: Add common Salesforce tabs (Home, Accounts, Contacts, etc.)
- **Use clear, descriptive application names**
- **Group related functionality logically**
- **Consider different user roles and needs**
- **Test across different device types**
- **Ensure proper permissions and access control**
- **Provide meaningful descriptions for users**
- **Follow consistent naming conventions**
- **Always configure branding**: Set headerColor to create professional application identity
- **Use accessible brand colors**: Ensure hex colors have sufficient contrast (WCAG AA compliant)
- **Configure utility bars**: Add useful quick-access tools for users
- **Leverage action overrides**: Customize page layouts for specific objects using FlexiPages from flexipage expert
- **Use profile overrides**: Provide role-specific experiences by referencing different flexipage expert generated pages per profile

## Enhancement Rules
- **uiType**: Always set to "Lightning" for modern app experience
- **navType**: CRITICAL DECISION - Analyze user requirements carefully
    - Set to "Standard" (DEFAULT) for general business applications
    - Set to "Console" ONLY when workflow requires:
        - Managing multiple related records simultaneously with split-view capability
        - Multi-tab workspace for handling complex, interconnected data
        - Contextual information from multiple sources visible at once
    - Console examples: customer service operations, call centers, support desks
    - When in doubt between Standard and Console, choose "Standard" for most business use cases
- **formFactors**: Always set to ["LARGE"] for desktop Lightning Experience
- **Standard Tabs**: Automatically add Home, Accounts, Contacts, Opportunities, Leads, Cases
- **Navigation Settings**: Set all navigation flags to false for best user experience
- **Branding**: ALWAYS include brand configuration for professional application identity
    - MANDATORY: Set brand.headerColor to appropriate color (e.g., "#0070D2" for Salesforce Blue)
    - Set brand.shouldOverrideOrgTheme based on requirements
- **Action Overrides**: ALWAYS create action overrides when custom record pages exist
    - MANDATORY: Add actionOverrides for "View" action pointing to flexipage expert generated record pages
    - Use "Flexipage" type and reference the exact FlexiPage name
    - Set formFactor to "Large" for desktop
    - Include pageOrSobjectType with the object API name
- **Profile Action Overrides**: Reference flexipage expert generated pages for role-based customization
- **Form Factors**: Use "Large" for desktop, "Small" for mobile in overrides

## CRITICAL Verification Checklist (MUST VERIFY)
- [ ] All tabs are included in the application
- [ ] **navType IS CORRECTLY SET** - Verify Console vs Standard selection
- [ ] Default to "Standard" for most general business applications
- [ ] Set to "Console" ONLY if workflow requires managing multiple records simultaneously, split-view, or multi-tab workspace
- [ ] If requirements are general/ambiguous → navType should be "Standard"
- [ ] **BRANDING IS CONFIGURED** - This is HIGHLY RECOMMENDED for professional applications
- [ ] brand.headerColor is set with valid hex color (e.g., "#0070D2")
- [ ] brand.shouldOverrideOrgTheme is set (default: false)
- [ ] **ACTION OVERRIDES ARE CREATED** - This is MANDATORY for every custom object with a record page
- [ ] Action overrides are defined for EACH custom object tab pointing to the correct record page
- [ ] actionOverrides.content matches the exact FlexiPage name generated by flexipage expert
- [ ] actionOverrides.pageOrSobjectType is set to the correct object API name
- [ ] actionOverrides.type is set to "Flexipage"
- [ ] actionOverrides.actionName is set to "View"
- [ ] actionOverrides.formFactor is set to "Large"
- [ ] All required fields are populated (fullName, label, uiType, navType, formFactors)

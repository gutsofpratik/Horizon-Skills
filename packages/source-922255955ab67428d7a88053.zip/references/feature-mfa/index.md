# Auth0 MFA

Require a second authentication factor - during login, or step-up before a sensitive action - and enforce it where it cannot be bypassed: on the tenant and on your API. For adding a first login to an app, use the `framework-*` reference instead; MFA layers on top of an existing login.

## When to use / when NOT to use

**Use when** the app must:

- Require a second factor for all logins (baseline enforcement).
- Step up to MFA before a specific sensitive action (payment, settings change, admin operation) without forcing it on every login.
- Require MFA conditionally based on risk, role, client, or requested scopes (adaptive MFA).
- Meet a compliance obligation that mandates multi-factor (PCI-DSS, SOC 2, HIPAA).

**Do NOT use this reference when:**

- The task is adding the initial login/logout to an app - that is the `framework-*` reference. MFA presupposes a working login.
- The request is passkeys/WebAuthn as the *primary* passwordless factor rather than a second factor - the mechanic overlaps but the framing differs; still route here for the enrollment surface, but treat passwordless login as a login concern.
- The task is only tenant provisioning with no application behavior - defer to `tooling-*`.

## Concepts

- **Factor** - a verification method (TOTP/OTP, SMS, email, push, WebAuthn, voice, recovery code).
- **Step-up authentication** - requiring MFA for a specific action after an initial login that did not use MFA.
- **Adaptive MFA** - requiring MFA conditionally from risk or context signals rather than always.

## SDK integration

MFA must be enforced in two independent places; getting either wrong ships a bypass:

1. **Tenant / login flow** - the tenant decides MFA is required (Guardian policy or Action). This is what actually challenges the user. See "Tenant configuration".
2. **Application** - the app triggers the step-up and *verifies* the result. Triggering alone enforces nothing; verification closes the bypass.

**Pick one mechanic:**

- App redirects to Universal Login (regular web app or SPA) -> **browser step-up** below.
- App collects credentials itself (a direct-grant or passwordless backend, e.g. `@auth0/auth0-auth-js` / `@auth0/auth0-server-js`) -> **API-driven MFA** below; skip the browser-step-up section.

Before writing code, read the detected SDK's example (see "Example code snippets").

### Scope — do this, then stop

The deliverable is the **application code**, written from the detected SDK's example file. Write it early; do not spend the task investigating. Specifically:

- **Trust the per-SDK file's method/option names — they are verified against the installed SDK.** Do NOT grep `node_modules`, read `.d.ts`/`.d.cts`/site-packages/SDK source, run the SDK's own test suite, or write throwaway `python -c`/`node -e` probes to confirm a signature. Write the code; inspect the installed package only if a specific line you wrote fails to compile, and then only that line.
- **The minimum version in each SDK file is informational.** The scaffold already pins a compatible release, so don't read `node_modules`/`package.json` to confirm the installed version meets it — only `verify — X+` rows call for a check.
- **Don't add dependencies you weren't asked for.** A `barcode_uri`/`barcodeUri` is a string you can render or return as-is; don't `npm install` a QR library unless the task requires rendering one.
- You're done when the app code is in place (and, for a JS/TS app, `npm run build` passes if quick). Stop there.

### The mechanic: browser step-up

Recipe (do in order):

1. **Trigger.** Send the authorization request with the PAPE multi-factor `acr_values` and
   `max_age=0` (forces a fresh challenge so a live session cannot satisfy it silently).
   Every SDK wraps this one shape:

   ```
   GET /authorize?...&acr_values=http://schemas.openid.net/pape/policies/2007/06/multi-factor&max_age=0
   ```

2. **Verify** completion with the signal that matches your audience (table below).
3. **Enforce** that same signal server-side on every protected endpoint, rejecting when it
   is absent. A frontend check is UX, never security.
4. **Conditional MFA:** require it from a post-login Action calling `api.multifactor.enable(...)`.

| Your context | Verify with |
|---|---|
| Session-managing SDK (web app) | The `amr` claim (contains `mfa` when MFA completed) off the SDK's own session / current-user accessor - already validated, so trust it as-is. Accessor name is SDK-specific -> see the SDK's own example ("Example code snippets" below). |
| Resource API (raw bearer token) | The high-value **scope** (e.g. `transfer:funds`) on the access token, via your *existing* JWT/scope-check middleware - see "Related capabilities". For `express-oauth2-jwt-bearer`, read the express-jwt skill reference and add the step-up scope to the existing `requiredScopes()` as a space-separated string or array (`requiredScopes('write:transfers transfer:funds')`); passing multiple string args (`requiredScopes('a', 'b')`) silently drops all but the first and leaves the gate open. |
| Frontend | Nothing - treat any `amr` check as UX, never enforcement. |

Notes: a silent token request may instead surface an `mfa_required` error - handle it by
re-authenticating interactively. Never re-decode or re-verify the token by hand (see
"Common mistakes"). Some session SDKs persist only a default subset of ID-token claims, so
`amr` can be missing from the accessor until you opt it in (see "Common mistakes"). `amr` is not a reliable contract for *which* factor ran; to enforce a
**specific** factor, have the post-login Action read `event.authentication.methods[].type`
into a custom claim. Action-defined MFA overrides the Guardian policy (it refines, not
replaces) and differs from **Adaptive MFA** (the Guardian `confidence-score` policy, owned
by `tooling-*`); if the `all-applications` policy is set, an Action can only add conditions,
not relax it.

### The mechanic: API-driven MFA (no-redirect flows)

The app collects credentials, so no browser runs the challenge: sign-in returns an
`mfa_required` error carrying an `mfa_token`. Each step is a method on the SDK's own MFA
client - get exact names from the SDK's own example ("Example code snippets" below); never hand-roll the token grant
or the MFA API URLs.

Recipe (do in order):

1. **Read the token.** Catch `mfa_required`; read `mfa_token` off it.
2. **Branch on enrollment.**
   - *No factor yet* -> associate (enroll). OTP returns a `barcode_uri` to render as a QR
     code; out-of-band (SMS/voice/email/push) returns an `oob_code` you confirm by
     submitting it directly to the token endpoint (MFA OOB grant, plus a `binding_code`
     when the channel requires one) - a just-associated authenticator needs no separate
     `/mfa/challenge`. Recovery codes are returned only on first enrollment.
   - *Already enrolled* -> challenge the existing authenticator so the user is prompted for
     its code.

   (An explicit enrolled/not-enrolled check or branching on the error's requirements are both fine.)
3. **Verify to finish.** Always carries the `mfa_token`: submit an OTP code as `otp`; for an
   already-enrolled out-of-band factor, `/mfa/challenge` first for a fresh `oob_code`, then
   submit it (plus a `binding_code` when needed); submit a recovery code as `recovery_code`
   (its own recovery-code grant, not treated as an OTP). Success returns tokens like an
   ordinary sign-in.
4. **Self-service management.** List and remove factors through the MFA client, not the
   Management API. List and challenge use the `mfa_token`; **removal needs a post-MFA access
   token** (`https://{yourDomain}/mfa/` audience + `remove:authenticators` scope) - the
   `mfa_token` alone does not authorize the `DELETE`. See "MFA API surface".

### Feature-level symbols

Protocol-level names that are identical across every SDK - what a grader would assert
and what the app must get right:

| Symbol | Meaning |
|---|---|
| `acr_values` | Authorization-request parameter used to request MFA |
| `http://schemas.openid.net/pape/policies/2007/06/multi-factor` | The PAPE value that requests multi-factor |
| `max_age=0` | Forces fresh authentication so a live session cannot satisfy the step-up silently |
| `amr` | ID-token claim listing the methods used; contains `mfa` when MFA completed. Not present on access tokens by default |
| `acr` | Claim echoing the satisfied authentication context |
| high-value scope | An API scope (e.g. `transfer:funds`) whose request an Action gates behind MFA; its presence on the access token is the API-side proof of step-up |
| `api.multifactor.enable(...)` | Post-login Action call that requires MFA for the current login |

SDK-specific symbols (an SDK's own method or option name - e.g. the silent-token call,
the `mfa_required`/`MfaRequiredError` handling, the interactive re-auth option, refresh-token
requirements) are **not** listed here; get them from the SDK's own example (see "Example code snippets").

### `amr` claim values

The `amr` array reports how the user authenticated (protocol-level; KEEP INLINE):

| Value | Meaning |
|---|---|
| `pwd` | Password |
| `mfa` | Multi-factor authentication completed |
| `otp` | One-time password (TOTP authenticator app) |
| `sms` | SMS code |
| `email` | Email code |
| `hwk` | Hardware key (WebAuthn security key) |
| `swk` | Software key |
| `pop` | Proof of possession |
| `fed` | Federated (social / enterprise) |

### Error responses

Returned by the token/authorization endpoints during an MFA flow (KEEP INLINE):

| Error | Cause | Handling |
|---|---|---|
| `mfa_required` | MFA has not been completed | Browser flow: re-authenticate interactively with the step-up parameters. No-redirect flow: read the `mfa_token` off the error and drive the MFA API (enroll/challenge/verify) |
| `association_required` | The user has no authenticator enrolled | Send the user through enrollment (self-service or enrollment ticket), then challenge |
| `unsupported_challenge_type` | The app supports none of the challenge types the user is enrolled with, or the user is not enrolled | Align the app's supported challenge types with the user's enrolled authenticators (or enroll the user) - do NOT change tenant config first |
| `mfa_invalid_code` | Wrong OTP entered | Prompt to retry |
| `too_many_attempts` | Repeated failures | Back off; the account may be temporarily blocked |

### Example code snippets

**Before writing MFA code:** find the detected SDK's row below and **`Read:` the file in its
Reference column** (the path is relative to the skill root, e.g. `Read: references/feature-mfa/auth0-react.md`).
That file is required reading — it has the SDK's exact method/option names for the step-up
and/or MFA API flow, plus the minimum version the feature needs. These files are the trusted
source; implement directly from them. The method and option names in them are verified against
the installed SDK — **do NOT re-verify signatures** by grepping `node_modules`, reading `.d.ts`
files or SDK source, fetching from GitHub, web-searching "how to do MFA", or querying the
auth0-docs MCP. Write the code from the file. Only inspect `node_modules` if a specific call
you wrote fails to compile — and then only that call. No matching row (a backend SDK not
listed)? Fall back to the language-neutral mechanic above.

**Min version** is the earliest SDK release where the feature shipped; `verify — X+` marks a
version to confirm against the installed package. If the app pins an older version, upgrade
it first or fall back to the language-neutral mechanic. Several MFA API flows are Early Access
(noted in the file) and need tenant enablement.

| SDK | Min version | Flow(s) | Reference (Read this file) |
|---|---|---|---|
| `@auth0/auth0-react` | 2.14.0 (MFA API) · 2.15.0 (popup step-up) | popup step-up, MFA API | `references/feature-mfa/auth0-react.md` |
| `@auth0/auth0-vue` | 2.6.0 | popup step-up, MFA API | `references/feature-mfa/auth0-vue.md` |
| `@auth0/auth0-angular` | 2.9.0 | popup step-up, MFA API | `references/feature-mfa/auth0-angular.md` |
| `@auth0/auth0-spa-js` | 2.16.0 | popup step-up | `references/feature-mfa/auth0-spa-js.md` |
| `@auth0/nextjs-auth0` | 4.15.0 (MFA + APIs) · verify — 4.19+ (popup step-up) | step-up, MFA API, popup | `references/feature-mfa/nextjs-auth0.md` |
| `@auth0/auth0-auth-js` | 1.8.0 | MFA API | `references/feature-mfa/auth0-auth-js.md` |
| `@auth0/auth0-server-js` | 1.5.0 | MFA API | `references/feature-mfa/auth0-server-js.md` |
| `express-openid-connect` | 2.17.0 | redirect step-up | `references/feature-mfa/express-oidc.md` |
| `Auth0.swift` (iOS/macOS) | verify — 3.0+ | MFA API | `references/feature-mfa/auth0-swift.md` |
| `Auth0.Android` | verify — 3.13+ | MFA API | `references/feature-mfa/auth0-android.md` |
| `react-native-auth0` | 5.10.0 | MFA API | `references/feature-mfa/react-native-auth0.md` |
| `auth0-server-python` | 1.0.0b10 (MFA API) · 1.0.0b15 (step-up) | step-up, MFA API | `references/feature-mfa/auth0-server-python.md` |
| `Auth0.OidcClient.*` (.NET native/desktop) | 4.4.0 | client-initiated step-up | `references/feature-mfa/oidc-client-net.md` |
| `go-jwt-middleware` (Go, resource server) | v2.2.1 | API-side scope gate | `references/feature-mfa/go-jwt-middleware.md` |
| `Auth0.AspNetCore.Authentication.Api` (resource server) | 1.0.1 | API-side scope gate | `references/feature-mfa/aspnetcore-api.md` |
| `spring-boot-starter-oauth2-resource-server` (Java) | Spring Boot 3.3 / Security 6 | API-side scope gate | `references/feature-mfa/spring-security-api.md` |
| `auth0-api-python` (Python resource server) | 1.0.0b10 | API-side scope gate | `references/feature-mfa/auth0-api-python.md` |

Note: the resource-server rows (`go-jwt-middleware`, `Auth0.AspNetCore.Authentication.Api`, Spring
Security, `auth0-api-python`) do not run MFA — the API enforces the step-up **scope** the tenant issues post-MFA, gating a
sensitive route on it. `Auth0.OidcClient.*` is a native client that triggers step-up via `acr_values`.

Note: the JS SPA/framework SDKs (`auth0-react`, `auth0-vue`, `auth0-angular`, `auth0-spa-js`)
drive step-up through the SDK's `interactiveErrorHandler: 'popup'` option, not the
`acr_values`/`max_age=0` parameters of the language-neutral mechanic above — see the file.

## Tenant configuration

A factor must be enabled before anything can challenge with it; enabling a factor alone
never prompts anyone until an enforcement path requires it, and setting enforcement
before any factor is enabled leaves users unable to complete MFA. So enable the factor
first, then choose an enforcement path - the two are independent:

- **Tenant-wide (Guardian policy)** - set `guardian/policies` to `["all-applications"]` to
  require MFA for *every* application on every login. This is the only path the ordering
  rule above is about, and the CLI anchor below shows it.
- **Conditional (post-login Action)** - enable the factor and configure an Action that
  calls `api.multifactor.enable(...)`; do **not** set the `all-applications` policy, or MFA
  becomes mandatory for every application instead of the conditions the Action defines.

The CLI anchor for the tenant-wide path (enable factors, then enforce the policy). SMS requires three separate endpoints — `guardian/factors/sms` does not accept `message_type` or `provider` in its body (returns 400); use the phone sub-endpoints below:

```bash
# TOTP / Authenticator app
auth0 guardian factors set otp --enabled

# SMS — three separate commands required
auth0 guardian factors set sms --enabled
auth0 guardian factors phone set-message-types --message-type sms
auth0 guardian factors phone set-provider --provider auth0   # legacy phone config only; unified-phone tenants set the provider in Dashboard > Branding > Phone Provider

# Email
auth0 guardian factors set email --enabled

# Enforce MFA for all applications
auth0 guardian policies set --policy all-applications

# Verify
auth0 guardian factors list
```

The full factor set, the `confidence-score` (adaptive) policy, the Terraform
`auth0_guardian` resource, and MCP coverage are owned by the loaded `tooling-*`
reference (DEFER ACROSS): the Auth0 MCP server exposes no Guardian/MFA tool, so
tenant MFA config is CLI or Terraform only.

### MFA API surface (in-flow self-service)

The mechanic above wraps these MFA API endpoints - the language-neutral floor that every
SDK wraps; do not call them by hand. None need a Management API admin scope, but they do
not all take the same credential: enrolling, challenging, and listing run on the
`mfa_token` from the `mfa_required` error, while removing an authenticator requires a
post-MFA access token with the `https://{yourDomain}/mfa/` audience and the
`remove:authenticators` scope:

| Operation | Endpoint | Authorized by |
|---|---|---|
| Enroll (associate) a new authenticator | `POST /mfa/associate` | `mfa_token` when the user has no active factor yet; otherwise an `enroll`-scoped access token for the `https://{yourDomain}/mfa/` audience |
| List the user's enrolled authenticators | `GET /mfa/authenticators` | `mfa_token` |
| Challenge an enrolled authenticator | `POST /mfa/challenge` | `mfa_token` |
| Remove an enrolled authenticator | `DELETE /mfa/authenticators/{id}` | post-MFA access token, `remove:authenticators` scope, mfa audience |
| Complete sign-in with the verified factor | `POST /oauth/token` (MFA grant) | `mfa_token` |

### Management API surface (admin / out-of-band enrollment)

Only for acting on a user *by id* with a Management API token (an admin dashboard or a
provisioning back-end) - **not** for a user managing their own factors in the flow above,
which uses the `mfa_token` and the MFA API surface instead:

| Operation | Endpoint |
|---|---|
| List a user's authentication methods | `GET users/{id}/authentication-methods` |
| Delete one authentication method | `DELETE users/{id}/authentication-methods/{authentication_method_id}` |
| Send an enrollment ticket | `POST guardian/enrollments/ticket` |

## Common mistakes

| Mistake | Why it breaks | Correct approach |
|---|---|---|
| Setting a Guardian policy before enabling any factor | Users are required to do MFA but have no factor to complete it with | Enable the factor first, then set the policy |
| Treating an enabled factor as enforcement | A factor with no policy never challenges anyone | Enforce with a policy or a post-login Action |
| Reading `guardian/policies` as `[]` and assuming MFA is on | `[]` means available but not required | Confirm a non-empty policy (or an Action that enables MFA) |
| Trusting a frontend MFA check | The client can be bypassed entirely | Enforce server-side: `amr` on a web/session backend, the high-value scope on a resource API |
| Checking `amr` on a resource API's access token | Access tokens carry no `amr` by default, so valid stepped-up callers are rejected | Gate the API on the high-value scope; add `amr` as a custom claim only if this API also validates it |
| Hand-decoding the token to read `amr` (`jwt.decode`, `PyJWKClient`, `id_token.split`, manual JWKS) | Reinvents validation the SDK already performed, and usually disables `exp`/`iss`/audience checks in the process | Read `amr` from the SDK's session/current-user accessor; its claims are already verified |
| Assuming the session accessor always carries `amr` | Some SDKs persist only a default claim subset, so `amr` is silently absent and the check never passes | Opt the claim in: `@auth0/nextjs-auth0` v4 needs a `beforeSessionSaved` hook to copy `amr` into the session (`session.user.amr`); `express-openid-connect` keeps the full claims on `req.oidc.idTokenClaims`, not the filtered `req.oidc.user` |
| Omitting `max_age=0` on step-up | A still-valid session satisfies the request with no fresh challenge | Send `max_age=0` (or the SDK's fresh-auth option) for step-up |
| Ignoring `mfa_required` from a silent token call | The step-up silently fails and the action proceeds unverified | Catch it and re-authenticate interactively |
| Preferring SMS by default | SMS is vulnerable to SIM-swap | Prefer TOTP or WebAuthn; treat SMS as a fallback |
| No recovery codes enabled | Users get locked out when they lose a device | Enable recovery codes during enrollment |
| Wrong HTTP verb on `guardian/policies` | Returns a misleading 404 | Use `auth0 guardian policies set --policy all-applications` |
| Sending `message_type` or `provider` to `guardian/factors/sms` directly | Returns a 400 — those fields are not accepted on that endpoint | Use `auth0 guardian factors phone set-message-types --message-type sms` for the message type and `auth0 guardian factors phone set-provider --provider auth0` for the provider (legacy phone config only — on the unified phone experience, set the provider in Dashboard > Branding > Phone Provider) |
| Using the Management API to list or remove a user's own factors during the sign-in flow | Forces the app to hold Management API admin scopes and ignores the `mfa_token` the flow already issued | List and challenge through the SDK's MFA client on the `mfa_token`; remove with a post-MFA `remove:authenticators` access token (mfa audience); reserve the Management API for admin / out-of-band |
| Assuming an already-enrolled factor needs no challenge and jumping straight to verify | Diverges from the SDK's documented enrolled-factor flow and breaks for out-of-band factors (SMS/push), whose challenge is what delivers the code | Challenge the enrolled authenticator, then verify |

## Related capabilities

- **Tenant setup and Actions** - `tooling-cli` and `tooling-terraform` own Guardian
  factor/policy configuration and Action deployment (`auth0 actions ...`).
- **SDK-side step-up trigger** - the SDK's own step-up call, its `mfa_required` handling,
  and any refresh-token requirement live in that SDK's own example (see "Example code
  snippets"), not in a `framework-*` reference.
- **Server-side MFA enforcement** - the API `framework-*` references (JWT validation) own
  the scope/claim-check middleware; on a resource API gate the sensitive endpoint on the
  high-value scope (access tokens carry no `amr` by default), and on a web/session backend
  check the `amr` claim.
- **First login** - if the app has no login yet, add it with the `framework-*` reference
  before layering MFA.

## References

Run `auth0 docs search "multi-factor authentication"` for the latest Auth0 docs on this topic.

[Auth0 MFA docs](https://auth0.com/docs/secure/multi-factor-authentication)
[Step-Up Authentication](https://auth0.com/docs/secure/multi-factor-authentication/step-up-authentication).

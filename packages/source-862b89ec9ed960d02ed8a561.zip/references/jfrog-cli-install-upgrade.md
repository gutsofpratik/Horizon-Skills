# JFrog CLI Install & Upgrade

## Minimum version for skills

Skills that call `jf api` require JFrog CLI **2.100.0** or later. On an older CLI
`jf api` is an unknown command, so the login flow stops as a prerequisite failure
rather than reaching the platform. Web login itself needs **2.86.0** or later.

Check with `jf --version`, and upgrade below that floor using the steps below.

## Installing the JFrog CLI

If `jf` is not installed (environment check exits with code 2), guide the user:

```bash
# macOS
brew install jfrog-cli

# Linux / generic
curl -fL https://install-cli.jfrog.io | sh
```

After installation, run `jf --version` to confirm, then
`bash <skill_path>/scripts/check-environment.sh <model-slug> --force`.

## Upgrading the JFrog CLI

On `NEWER_AVAILABLE`, run
`bash <skill_path>/scripts/cli-newer-version-offer.sh --clear` immediately.
Never interrupt the task: finish the user's task first, then offer the upgrade
as the last line of the reply. Upgrade only after the user says Yes:

```bash
# macOS
brew upgrade jfrog-cli

# Linux / generic (reinstall)
curl -fL https://install-cli.jfrog.io | sh
```

After upgrading, run `jf --version` to confirm, then
`bash <skill_path>/scripts/check-environment.sh <model-slug> --force`.

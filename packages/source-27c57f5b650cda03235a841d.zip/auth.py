"""
Confidence Auth0 PKCE login flow.

Usage:
    python3 auth.py <CLIENT_ID> [ORGANIZATION]
    python3 auth.py <CLIENT_ID> login    # existing account (no signup hint)

Tokens are written directly to $TMPDIR/confidence_token (and
$TMPDIR/confidence_refresh_token if granted) — never printed to stdout.

Outputs on stdout:
    WAITING_FOR_LOGIN       — browser opened, waiting for callback
    SUCCESS                 — tokens written to $TMPDIR
    AUTH_ERROR:<msg>        — auth0 returned an error
    TOKEN_ERROR:<msg>       — token exchange failed

Exit codes: 0 = success, 1 = error
"""
import http.server, urllib.parse, json, sys, subprocess, hashlib, base64, secrets, string, os, stat, socket

CLIENT_ID = sys.argv[1]
ORGANIZATION = sys.argv[2] if len(sys.argv) > 2 else ''

code_verifier = ''.join(secrets.choice(string.ascii_letters + string.digits + '-._~') for _ in range(43))
code_challenge = base64.urlsafe_b64encode(hashlib.sha256(code_verifier.encode()).digest()).rstrip(b'=').decode()
state = secrets.token_urlsafe(32)

port = 8084
REDIRECT_URI = f'http://localhost:{port}/callback'
auth_code = None
error = None

class Handler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        global auth_code, error
        q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
        self.send_response(200)
        self.send_header('Content-Type', 'text/html')
        self.end_headers()
        returned_state = q.get('state', [None])[0]
        if returned_state != state:
            error = 'state_mismatch'
            self.wfile.write(b'<h1>Login failed</h1><p>State mismatch. Please try again.</p>')
        elif 'code' in q:
            auth_code = q['code'][0]
            self.wfile.write(b'<h1>Login successful!</h1><p>You can close this tab.</p>')
        else:
            error = q.get('error', ['unknown'])[0]
            self.wfile.write(b'<h1>Login failed</h1><p>Please try again.</p>')
    def log_message(self, format, *args):
        pass

params = {
    'client_id': CLIENT_ID,
    'redirect_uri': REDIRECT_URI,
    'response_type': 'code',
    'scope': 'openid profile email offline_access',
    'audience': 'https://confidence.dev/',
    'code_challenge': code_challenge,
    'code_challenge_method': 'S256',
    'state': state,
}
if ORGANIZATION in ('login', '--login'):
    params['prompt'] = 'login'
elif ORGANIZATION:
    params['organization'] = ORGANIZATION
else:
    params['screen_hint'] = 'signup'
    params['prompt'] = 'login'

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
try:
    sock.bind(('127.0.0.1', port))
    sock.close()
except OSError:
    print(f'AUTH_ERROR:port_{port}_in_use', flush=True)
    sys.exit(1)

authorize_url = 'https://auth.confidence.dev/authorize?' + urllib.parse.urlencode(params)
subprocess.Popen(['open', authorize_url])
print('WAITING_FOR_LOGIN', flush=True)

server = http.server.HTTPServer(('127.0.0.1', port), Handler)
server.timeout = 120
while auth_code is None and error is None:
    server.handle_request()
server.server_close()

if error:
    print(f'AUTH_ERROR:{error}', flush=True)
    sys.exit(1)

import urllib.request
token_data = json.dumps({
    'grant_type': 'authorization_code',
    'client_id': CLIENT_ID,
    'code': auth_code,
    'redirect_uri': REDIRECT_URI,
    'code_verifier': code_verifier
}).encode()
req = urllib.request.Request(
    'https://auth.confidence.dev/oauth/token',
    data=token_data,
    headers={'Content-Type': 'application/json'}
)
try:
    with urllib.request.urlopen(req) as resp:
        token_response = json.loads(resp.read())
    tmpdir = os.environ.get('TMPDIR', '/tmp')
    token_path = os.path.join(tmpdir, 'confidence_token')
    with open(token_path, 'w') as f:
        f.write(token_response['access_token'])
    os.chmod(token_path, stat.S_IRUSR | stat.S_IWUSR)
    if 'refresh_token' in token_response:
        refresh_path = os.path.join(tmpdir, 'confidence_refresh_token')
        with open(refresh_path, 'w') as f:
            f.write(token_response['refresh_token'])
        os.chmod(refresh_path, stat.S_IRUSR | stat.S_IWUSR)
    print('SUCCESS', flush=True)
except Exception as e:
    print(f'TOKEN_ERROR:{e}', flush=True)
    sys.exit(1)

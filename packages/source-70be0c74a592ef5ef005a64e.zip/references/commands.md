# Bright Data CLI — Full Command Reference

**Package:** `@brightdata/cli` | **Commands:** `brightdata` / `bdata` (shorthand) | **Requires:** Node.js >= 20

## Installation

```bash
# macOS / Linux
curl -fsSL https://cli.brightdata.com/install.sh | bash

# Any platform
npm install -g @brightdata/cli

# Without installing
npx --yes --package @brightdata/cli brightdata <command>
```

---

## Global Options

These flags work with any command:

| Flag | Description |
|------|-------------|
| `-k, --api-key <key>` | Override API key for this request |
| `--timing` | Show request timing info |
| `-v, --version` | Show CLI version |

---

## `bdata login`

Authenticate with Bright Data. Opens the browser for OAuth by default.

| Flag | Description |
|------|-------------|
| `-k, --api-key <key>` | Use API key directly (skips browser) |
| `-c, --customer-id <id>` | Bright Data account ID (optional) |
| `-d, --device` | Use device flow for SSH/headless environments |

**What happens on login:**
1. Opens browser for OAuth (or uses device flow / direct API key)
2. Validates the API key
3. Saves credentials locally (`~/.config/brightdata-cli/credentials.json`)
4. Checks for required zones (`cli_unlocker`, `cli_browser`)
5. Creates missing zones automatically
6. Sets `cli_unlocker` as default zone if none configured

```bash
bdata login                        # Browser OAuth (recommended)
bdata login --device               # Headless/SSH environments
bdata login --api-key <key>        # Direct API key
```

---

## `bdata logout`

Clear stored credentials.

```bash
bdata logout
```

---

## `bdata scrape <url>`

Scrape any URL using Bright Data's Web Unlocker. Handles CAPTCHAs, JavaScript rendering, and anti-bot protections automatically.

| Flag | Description |
|------|-------------|
| `-f, --format <fmt>` | `markdown` (default), `html`, `screenshot`, `json` |
| `--country <code>` | ISO country code for geo-targeting (e.g. `us`, `de`, `jp`) |
| `--zone <name>` | Web Unlocker zone name |
| `--mobile` | Use a mobile user agent |
| `--async` | Submit async, return a snapshot ID |
| `-o, --output <path>` | Write output to file |
| `--json` | Force JSON output |
| `--pretty` | Pretty-print JSON output |

```bash
bdata scrape https://news.ycombinator.com
bdata scrape https://example.com -f html
bdata scrape https://amazon.com -f json --country us -o product.json
bdata scrape https://example.com -f screenshot -o page.png
bdata scrape https://example.com --async
bdata scrape https://docs.github.com | glow -
```

---

## `bdata search <query>`

Search Google, Bing, or Yandex via Bright Data's SERP API.

Google returns structured JSON with: organic results, ads, People Also Ask, related searches.
Bing/Yandex return markdown by default.

| Flag | Description |
|------|-------------|
| `--engine <name>` | `google` (default), `bing`, `yandex` |
| `--country <code>` | Localized results (e.g. `us`, `de`) |
| `--language <code>` | Language code (e.g. `en`, `fr`) |
| `--page <n>` | Page number, 0-indexed (default: `0`) |
| `--type <type>` | `web` (default), `news`, `images`, `shopping` |
| `--device <type>` | `desktop`, `mobile` |
| `--zone <name>` | SERP zone name |
| `-o, --output <path>` | Write output to file |
| `--json` | Force JSON output |
| `--pretty` | Pretty-print JSON output |

```bash
bdata search "typescript best practices"
bdata search "restaurants berlin" --country de --language de
bdata search "AI regulation" --type news
bdata search "web scraping" --page 1
bdata search "open source scraping" --json | jq -r '.organic[].link'
bdata search "bright data pricing" --engine bing
```

---

## `bdata pipelines <command>`

Run any pre-built Scraper API scraper. Requires CLI 0.4.0+.

| Command | Purpose |
|---------|---------|
| `bdata pipelines search <query...>` | Find a scraper by site or data type (`--limit <n>`, default 10) |
| `bdata pipelines info <dataset_id> [method]` | List methods, or one method's input fields and example input |
| `bdata pipelines run <dataset_id> <method> [urls...] [--<field> <value>...]` | Run a scraper |
| `bdata pipelines status <snapshot_id>` | Run progress (`--wait`, `--timeout`) |
| `bdata pipelines results <snapshot_id>` | Records of a finished run (`--format`) |
| `bdata pipelines refresh` | Reload the scraper list |

`run` flags:

| Flag | Description |
|------|-------------|
| `--<field> <value>` | An input field of the method, as listed by `info` |
| `--input <json\|@file>` | Input records as JSON, or `@path` to a JSON file |
| `--limit-per-input <n>` | `discover_by_*` only: max records per input (default: `10`) |
| `--async` | Print the snapshot ID instead of waiting |
| `--format <fmt>` | `json` (default), `csv`, `ndjson`, `jsonl` |
| `--timeout <seconds>` | How long to wait (default: `600`) |
| `-o, --output <path>` | Write output to file |
| `--json` / `--pretty` | JSON output |

```bash
bdata pipelines search "<site or data type>"
bdata pipelines info <dataset_id> <method>
bdata pipelines run <dataset_id> collect_by_url "<url>" --format csv -o out.csv
bdata pipelines run <dataset_id> <method> --input @records.json --async
bdata pipelines status <snapshot_id> --wait
bdata pipelines results <snapshot_id> --pretty
```

See [pipelines.md](pipelines.md) for the full workflow.

---

## `bdata zones`

List and inspect Bright Data proxy zones.

```bash
bdata zones                        # List all active zones
bdata zones info <name>            # Full details for a zone
bdata zones --json -o zones.json   # Export as JSON
bdata zones info my_zone --pretty  # Pretty-print zone info
```

---

## `bdata budget`

View account balance and per-zone cost/bandwidth. Read-only.

> New accounts get **5,000 free credits/month** (~$7.50, 1 credit per
> request) shared across Unlocker, SERP, Web Scraper, and Scraper Studio;
> they reset on the 1st and don't roll over. Proxy and Browser API are
> billed separately (not from free credits). With no deposited funds a
> hard stop kicks in when credits run out — so a "balance" near zero on a
> free account is expected, not an error.
> See: https://docs.brightdata.com/general/account/billing-and-pricing/free-tier

| Subcommand | Description |
|------------|-------------|
| *(none)* | Quick account balance |
| `balance` | Balance + pending charges |
| `zones` | Cost & bandwidth table for all zones |
| `zone <name>` | Detailed cost & bandwidth for one zone |

| Flag | Description |
|------|-------------|
| `--from <datetime>` | Start of date range (e.g. `2024-01-01T00:00:00`) |
| `--to <datetime>` | End of date range |
| `--json` / `--pretty` | JSON output |

```bash
bdata budget
bdata budget balance
bdata budget zones
bdata budget zone my_zone
bdata budget zones --from 2024-01-01T00:00:00 --to 2024-02-01T00:00:00
```

---

## `bdata config`

View and manage CLI configuration.

| Subcommand | Description |
|------------|-------------|
| *(none)* | Show all config |
| `get <key>` | Get a single value |
| `set <key> <value>` | Set a value |

| Config Key | Description |
|------------|-------------|
| `default_zone_unlocker` | Default zone for `scrape` and `search` |
| `default_zone_serp` | Override zone for `search` only |
| `default_format` | Default output format: `markdown` or `json` |
| `api_url` | Override API base URL |

```bash
bdata config
bdata config set default_zone_unlocker my_zone
bdata config set default_format json
bdata config get default_zone_unlocker
```

---

## `bdata init`

Interactive setup wizard. Walks through authentication, zone selection, and default configuration.

| Flag | Description |
|------|-------------|
| `--skip-auth` | Skip the authentication step |
| `-k, --api-key <key>` | Provide API key directly |

```bash
bdata init
```

---

## `bdata skill`

Install Bright Data AI agent skills into coding agents (Claude Code, Cursor, Copilot, etc.).

| Subcommand | Description |
|------------|-------------|
| `add` | Interactive picker — choose skills + target agents |
| `add <name>` | Install a specific skill directly |
| `list` | List all available skills |

Available skills: `search`, `scrape`, `data-feeds`, `bright-data-mcp`, `bright-data-best-practices`

```bash
bdata skill add              # Interactive
bdata skill add scrape       # Direct install
bdata skill list             # See what's available
```

---

## Configuration Storage

| OS | Path |
|----|------|
| macOS | `~/Library/Application Support/brightdata-cli/` |
| Linux | `~/.config/brightdata-cli/` |
| Windows | `%APPDATA%\brightdata-cli\` |

Two files:
- `credentials.json` — API key (mode 0o600)
- `config.json` — Zones, output format, preferences

Priority order: CLI flags > Environment variables > config.json > Defaults

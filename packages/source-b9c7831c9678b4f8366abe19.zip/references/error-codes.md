# Error Codes — Zoom MCP Server

Errors can surface from the MCP protocol layer or from the underlying Zoom API-style behavior
behind a tool call.

## MCP Protocol Errors

| Code | Message | Cause | Fix |
|------|---------|-------|-----|
| `-32001` | `Access token is required` | Missing Authorization header because the bundled connector has no token | Set `ZOOM_MCP_ACCESS_TOKEN`, then restart Claude Code or re-enable the plugin |
| `-32001` | `Invalid access token` | Expired, revoked, malformed, or missing required scopes | Refresh the token and verify the MCP-specific scopes |
| `-32602` | `Can not found tool: ... in this MCP Server` | Wrong tool name or wrong MCP server surface | Re-run `tools/list` and use the current live tool names for that endpoint |
| `-32603` | `Call handle error` | Missing required parameter or server-side call handling failure | Re-check required arguments against the live schema and retry |

## Exact Scope Errors Observed in Testing

| Tool | Exact missing-scope error |
|------|---------------------------|
| `search_meetings` | `meeting:read:search` |
| `search_zoom` | `ai_companion:read:search` |
| `get_meeting_assets` | `meeting:read:assets` or `meeting:read:assets:admin` |
| `recordings_list` | `cloud_recording:read:list_user_recordings` or admin/master variants |
| `get_recording_resource` | `cloud_recording:read:content` |
| `create_new_file_with_markdown` | `docs:write:import` |
| `hub_create_file_from_content` | `hub:write:content` |
| `get_file_content` | `docs:read:export` |

## Recording and Transcript Failures

| Symptom | Likely cause | Fix |
|---------|-------------|-----|
| `get_recording_resource` fails on scope | Missing `cloud_recording:read:content` | Add the scope and mint a new token |
| Recording search/list works but transcript-capable retrieval fails | Token has list scope but not content scope | Add `cloud_recording:read:content` |
| Returned resource URL gives `401` | Bearer token not included on the follow-up fetch | Include the same bearer token on the direct request |
| `get_file_content` fails on scope | Token can search Docs but cannot export content | Add `docs:read:export` and mint a new token |

## Upstream API Validation Errors

Some tool calls can succeed at the MCP protocol layer but surface a downstream Zoom API
validation error in the result payload.

Common downstream validation response:

| Tool | Error shape | Cause | Fix |
|------|-------------|-------|-----|
| `create_new_file_with_markdown` | `Upstream API returned error status code: 400 ... "message":"invalid param"` | Invalid parameter value such as a bogus `parent_id` | Fix the argument value and retry |
| `create_file_with_content` | `Upstream API returned error status code: 400 ... "message":"invalid param"` | Invalid parameter value such as a bogus `parent_id` | Fix the argument value and retry |

## Product-Specific Server Split

The current Zoom MCP server (`mcp.zoom.us/mcp/zoom/streamable`), Meetings MCP
(`mcp.zoom.us/mcp/meeting/streamable`), Canvas MCP (`mcp.zoom.us/mcp/canvas/streamable`),
Chat MCP (`mcp.zoom.us/mcp/chat/streamable`), Tasks MCP (`mcp.zoom.us/mcp/tasks/streamable`),
Revenue Accelerator MCP (`mcp.zoom.us/mcp/revenue_accelerator/streamable`), and Whiteboard MCP
(`mcp.zoom.us/mcp/whiteboard/streamable`) are separate surfaces.

The old `/mcp/docs` and `/mcp/team_chat` paths are compatibility paths, not current catalog
entries. The Chat child skill remains under the `team-chat` folder for link compatibility.

Use the dedicated Whiteboard MCP skill for Whiteboard-specific auth, scopes, and identifier mapping:
- [../whiteboard/SKILL.md](../whiteboard/SKILL.md)

Use the Chat MCP child skill for Chat MCP auth, scopes, and safety rules:
- [../team-chat/SKILL.md](../team-chat/SKILL.md)

## Debugging Checklist

1. Confirm the client can discover the current MCP tool list through `tools/list`.
2. Confirm the bearer token is fresh.
3. Verify the exact MCP-specific scopes, not just adjacent REST scopes.
4. Re-discover the target meeting or recording instead of reusing guessed IDs.

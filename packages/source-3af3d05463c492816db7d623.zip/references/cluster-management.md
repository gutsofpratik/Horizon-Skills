# GPU Cluster Management Reference
## Contents

- [Cluster Architecture](#cluster-architecture)
- [Access Methods](#access-methods)
- [Slurm Configuration](#slurm-configuration)
  - [Startup Scripts (Slinky v1.0 only)](#startup-scripts-slinky-v10-only)
- [GPU Access in Containers](#gpu-access-in-containers)
- [Scaling](#scaling)
- [Storage](#storage)
- [Health Checks](#health-checks)
- [User Management](#user-management)
- [Billing](#billing)
- [Troubleshooting](#troubleshooting)
- [Terraform](#terraform)


## Cluster Architecture

### Kubernetes Mode
- **Control Plane** -- Manages cluster state, scheduling, API access
- **Worker Nodes** -- GPU-equipped nodes running workloads
- **Networking** -- High-speed InfiniBand for multi-node communication
- **Storage Layer** -- Persistent volumes, local NVMe, shared storage

### Slurm on Kubernetes (Slinky)
- **Slurm Controller** -- Runs as K8s pods, manages job queues
- **Login Nodes** -- SSH-accessible entry points
- **Compute Nodes** -- GPU workers registered with both K8s and Slurm

## Access Methods

### Kubernetes Access

```shell
# Get credentials
together beta clusters get-credentials <CLUSTER_ID>
export KUBECONFIG=$HOME/.kube/config

# Verify
kubectl get nodes
kubectl top nodes
kubectl get pods --all-namespaces
```

### Kubernetes Dashboard

Access the dashboard URL from the cluster UI. Retrieve the admin token:

```shell
kubectl -n kubernetes-dashboard get secret \
  $(kubectl -n kubernetes-dashboard get secret | grep admin-user-token | awk '{print $1}') \
  -o jsonpath='{.data.token}' | base64 -d | pbcopy
```

### SSH Access

Two SSH methods are supported. On Slurm clusters with OIDC enabled, pick one from the **SSH access method** selector in the cluster UI sidebar; the choice applies to the head node and all compute nodes. If OIDC is not configured on the cluster, only key-based SSH is available.

| Method | How it works | Requirements |
|--------|--------------|--------------|
| **OIDC (Together CLI)** | Browser sign-in that mints a short-lived certificate, executed via `tg beta clusters ssh`. | Together CLI installed (`uv tool install "together[cli]"`, 2.20+, Python 3.10+). Choose a login name when prompted in the cluster UI. No SSH key required. |
| **Key-based** | Standard `ssh -J` proxy jump through the cluster's bastion. | SSH public key uploaded at `api.together.ai/settings/ssh-key` before cluster creation. |

The cluster UI's **Copy SSH command** (worker/compute) and **Copy head node SSH command** (Slurm login) buttons emit a command shaped for the selected method.

**Key-based commands:**

```shell
# Worker node (Kubernetes) or Slurm compute node
ssh -J <LOGIN>@ssh.<CLUSTER_ID>.<REGION>.cloud.together.ai <LOGIN>@<NODE_HOSTNAME>

# Slurm login node
ssh -J <LOGIN>@ssh.<CLUSTER_ID>.<REGION>.cloud.together.ai <LOGIN>@slurm-login
```

**OIDC commands (Together CLI):**

```shell
# Worker node (Kubernetes) or Slurm compute node
tg beta clusters ssh https://dex.<REGION>.cloud.together.ai/<CLUSTER_ID> \
  --login <LOGIN> --host <NODE_HOSTNAME>

# Slurm login node (host defaults to the head node)
tg beta clusters ssh https://dex.<REGION>.cloud.together.ai/<CLUSTER_ID> --login <LOGIN>
```

If the CLI was previously installed with `pip`, migrate to the `uv`-managed install before using OIDC SSH: `pip uninstall together` and reinstall with `uv tool install "together[cli]"`.

**Slurm hostnames:**

- Compute nodes: `<NODE_NAME>.slurm-compute.slurm` (e.g., `gpu-dp-hmqnh-nwlnj.slurm-compute.slurm`)
- Login node: always `slurm-login`

### Slurm Commands

```shell
sinfo                    # Node and partition status
squeue                   # Job queue
srun --gres=gpu:8 --pty bash  # Interactive GPU session
sbatch script.sh         # Submit batch job
scancel <jobid>          # Cancel job
scontrol show node       # Detailed node info
scontrol show job <jobid>  # Job details
```

## Slurm Configuration

Slurm clusters use four config files managed via a Kubernetes ConfigMap:

- **slurm.conf**: Main cluster configuration (nodes, partitions, scheduling)
- **gres.conf**: GPU and generic resource definitions
- **cgroup.conf**: Control group resource management
- **plugstack.conf**: SPANK plugin configuration

### Partition Configuration

```
PartitionName=gpu Nodes=gpu-nodes State=UP Default=NO MaxTime=24:00:00
PartitionName=cpu Nodes=cpu-nodes State=UP Default=YES
```

### GPU Resource Configuration

```
Name=gpu Type=h100 File=/dev/nvidia[0-7]
```

### Scheduler Tuning

```
SchedulerParameters=batch_sched_delay=10,bf_interval=180,sched_max_job_start=500
```

### Cgroup Settings

```
CgroupPlugin=cgroup/v1
ConstrainCores=yes
ConstrainRAMSpace=yes
```

Changes require restarting the Slurm controller via `kubectl rollout restart` and verifying
with `scontrol` and `sinfo`.

### Startup Scripts (Slinky v1.0 only)

Lifecycle scripts that run automatically at node startup, job start, and job completion.
Configure under cluster **Specs and configuration -> Slurm configuration -> Edit**. Every
script must start with a shebang (`#!/bin/bash`); saving triggers a live Slurm reconfigure,
so test on a non-critical cluster first.

| Script | Runs on | When |
|--------|---------|------|
| Worker init | Each worker | Node boot, before jobs |
| Login init | Login node | Login-node startup |
| Worker prolog | Each worker | Before job (first job step by default; see `PrologFlags=Alloc`) |
| Worker epilog | Each worker | After job ends |
| Controller prolog | `slurmctld` | At job allocation |
| Controller epilog | `slurmctld` | At job completion |
| Extra slurm.conf | All nodes | Appended verbatim to `slurm.conf` |

**Failure modes:**

- Worker prolog or epilog non-zero exit -> node set to `DRAIN`. A worker prolog failure additionally requeues batch jobs and cancels interactive jobs (`salloc`, `srun`).
- Controller prolog non-zero exit -> batch job requeued, interactive job cancelled; node not affected.
- Controller epilog non-zero exit -> logged, no other effect.

Resume a drained node:

```shell
sudo scontrol update NodeName=<node_name> State=resume Reason="script fixed"
```

**Rules:**

- Do not call Slurm commands (`squeue`, `scontrol`, `sacctmgr`) inside a prolog or epilog; this can deadlock the scheduler.
- By default the worker prolog runs at first job step, not at allocation. Add `PrologFlags=Alloc` to **Extra slurm.conf** to run at allocation.
- After edits, existing workers may keep cached scripts via Slurm's configless mechanism. New jobs on those workers continue using the old scripts until the worker restarts.
- Use `set -e` in init scripts so failures surface immediately; use `SLURM_JOB_ID` and `SLURM_JOB_USER` in prolog/epilog to scope cleanup to the running job.

## GPU Access in Containers

GPU devices are exposed by the runtime to all containers, but CUDA support depends on the
container image. Use CUDA-enabled images like `pytorch/pytorch` or `nvidia/cuda`.

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: gpu-workload-pod
spec:
  restartPolicy: Never
  containers:
    - name: pytorch
      image: pytorch/pytorch:2.1.0-cuda12.1-cudnn8-runtime
      command: ["/bin/bash", "-c", "sleep infinity"]
      resources:
        limits:
          nvidia.com/gpu: 1
      volumeMounts:
        - name: shared-storage
          mountPath: /mnt/shared
  volumes:
    - name: shared-storage
      persistentVolumeClaim:
        claimName: shared-pvc
```

```shell
kubectl apply -f gpu-pod.yaml
kubectl wait --for=condition=Ready pod/gpu-workload-pod
kubectl exec -it gpu-workload-pod -- bash
nvidia-smi
```

## Scaling

### Real-time Scaling

Scale via UI, CLI, or API at any time. GPU count must be a multiple of 8.

```python
from together import Together
client = Together()

cluster = client.beta.clusters.update("cluster-id", num_gpus=16)
```

```shell
together beta clusters update <CLUSTER_ID> --num-gpus 16
```

### Autoscaling (Kubernetes)

Enable autoscaling during cluster creation in the UI. The Kubernetes Cluster Autoscaler:
- Scales up when pods are pending due to insufficient resources
- Scales down when nodes are underutilized
- Respects pod disruption budgets

### Targeted Scale-down

```shell
# Kubernetes -- cordon specific nodes
kubectl cordon <node_name>

# Slurm -- drain specific nodes
sudo scontrol update NodeName=<node_name> State=drain Reason="scaling down"
```

### Combining Capacity

Use reserved for baseline + on-demand for bursts.

## Storage

### Types

1. **Local NVMe** -- High-speed local I/O per node
2. **Shared /home** -- NFS-mounted across nodes (code, configs, logs)
3. **Shared Volumes** -- Multi-NIC, high-throughput persistent storage

### Kubernetes PVCs

**Shared storage (ReadWriteMany):**
```yaml
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: shared-pvc
spec:
  accessModes: [ReadWriteMany]
  resources:
    requests:
      storage: 10Gi
  volumeName: <shared-volume-name>
```

**Local storage (ReadWriteOnce):**
```yaml
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: local-pvc
spec:
  accessModes: [ReadWriteOnce]
  resources:
    requests:
      storage: 50Gi
  storageClassName: local-storage-class
```

```shell
kubectl apply -f shared-pvc.yaml -n default
kubectl apply -f local-pvc.yaml -n default
kubectl get pvc -A
```

### Pod with Volumes

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: test-pod
spec:
  restartPolicy: Never
  containers:
    - name: ubuntu
      image: debian:stable-slim
      command: ["/bin/sh", "-c", "sleep infinity"]
      volumeMounts:
        - name: shared-storage
          mountPath: /mnt/shared
        - name: local-storage
          mountPath: /mnt/local
  volumes:
    - name: shared-storage
      persistentVolumeClaim:
        claimName: shared-pvc
    - name: local-storage
      persistentVolumeClaim:
        claimName: local-pvc
```

### Data Upload

```shell
# Small files
kubectl cp LOCAL_FILE POD_NAME:/data/

# Large datasets via S3
# Deploy a data-loader pod with aws-cli
```

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: data-loader
spec:
  containers:
    - name: downloader
      image: amazon/aws-cli
      command: ["aws", "s3", "cp", "s3://bucket/data", "/mnt/shared/", "--recursive"]
      volumeMounts:
        - name: shared-storage
          mountPath: /mnt/shared
  volumes:
    - name: shared-storage
      persistentVolumeClaim:
        claimName: shared-pvc
```

## Health Checks

### Automatic Acceptance Testing

During provisioning, nodes undergo automatic tests:
- **DCGM Diag (Level 2)** -- GPU compute, memory, thermal validation
- **GPU Burn (5 min)** -- stress test for thermal/power issues
- **Single-Node NCCL** -- GPU-to-GPU communication within a node
- **Multi-Node NCCL** -- cross-node GPU communication
- **Storage Performance** -- sequential read/write throughput and data-integrity validation on attached storage volumes

Nodes showing "Tests Failed" are not added to the cluster until repaired.

### Available Health Check Tests

**GPU Diagnostics:**
- DCGM Diag (levels 1-3): NVIDIA Data Center GPU Manager diagnostics
- GPU Burn: intensive compute stress test

**Network Performance:**
- Single-Node NCCL: intra-node GPU communication
- InfiniBand Write Bandwidth: high-speed interconnect performance

**PCIe Performance:**
- NVBandwidth: CPU-to-GPU, GPU-to-CPU bandwidth, GPU-CPU latency

**Storage:**
- Storage Performance (Preview): `fio` sequential read/write throughput plus a checksummed write/read-back for data-integrity validation against the cluster's shared and local storage tiers. Contact [support](mailto:support@together.ai) for access.

### Passive Health Checks

Passive checks run continuously on every node and observe real workloads, GPU metrics, and system logs. They have zero impact on running jobs and require no manual action. When a node exhibits one of the conditions below, the system raises a named signal; signals that meet repair criteria generate an auto-repair recommendation.

**GPU and accelerator:**

| Signal | Condition |
|---|---|
| `DmesgGpuFallenOffBus` | GPU unreachable on the PCIe bus (hardware or connector failure) |
| `GpuSmClockThermalThrottle` | Sustained high temperature forces SM clocks down |
| `DmesgXidError` | NVIDIA driver or hardware Xid fault in the kernel log |
| `GpuEccDoubleBitError` | Uncorrectable (double-bit) GPU memory error |
| `GpuRowRemapFailure` | GPU memory row-remap failed; GPU likely needs RMA |
| `GpuPcieReplayRateHigh` | Degraded PCIe link integrity |

**InfiniBand networking:**

| Signal | Condition |
|---|---|
| `IBRailsDownOrDegraded` | Fewer than 8 active 400G IB rails (rail down or negotiated below 400G) |
| `IBLinkFlapping` | Repeated InfiniBand link-down events on a compute rail |

**Node OS, kernel, and resources:**

| Signal | Condition |
|---|---|
| `NpdCperHardwareErrorFatal` | Fatal CPER-reported platform hardware error |
| `NpdReadonlyFilesystem` | Root or data filesystem remounted read-only |
| `NpdXfsShutdown` | XFS filesystem shut down after an error |
| `NpdKernelDeadlock` | Kernel task stuck |
| `NpdFrequentKubeletRestart` | kubelet restarting repeatedly |
| `NpdFrequentContainerdRestart` | containerd restarting repeatedly |
| `NpdFrequentUnregisterNetDevice` | Repeated network device unregister events |
| `KubeNodeMemoryPressure` | Node under sustained memory pressure |
| `KubeNodeDiskPressure` | Node under sustained disk pressure |
| `KubeNodePIDPressure` | Node exhausting available process IDs |

**Scheduler:**

| Signal | Condition |
|---|---|
| `SlurmNodeUnavailable` | Slurm marks the node DOWN or DRAIN |

Detection coverage is expanding, and automated recommendations are enabled per cluster; not every signal triggers an automated recommendation today — some raise an internal alert that Together's team reviews first.

**Training Performance (preview):**
- TorchTitan Training: short [TorchTitan](https://github.com/pytorch/torchtitan) benchmark on one or more nodes, measuring steady-state median model FLOPs utilization (MFU) after skipping warmup. Catches grossly degraded nodes that still pass point-in-time diagnostics. **B200 only** (Blackwell, `sm_100`) -- the built-in CUDA and PyTorch stack (PyTorch with FlashAttention 4) does not run on other GPU types. Runtime is about 15 minutes (roughly 9 minutes init, 6 minutes run). Runs on demand and is not part of automatic acceptance testing; thresholds may change while in preview. Default pass threshold: steady-state median MFU >= 30% for Llama 3 8B on a single B200 node (reference ~36.5%). Larger models and multi-node runs use per-run reference values (for example, Llama 3 70B reaches ~38% MFU on 4 nodes).

### Node Repair

Auto repair uses three repair actions, ordered lightest to heaviest, plus a warning-only tier. If a lighter action does not clear the issue, it escalates. Every recommendation is reviewed and accepted by the user before a repair runs; training jobs must checkpoint first.

- **Reboot**: Restart the node in place. Fastest recovery; used for recoverable software or transient GPU faults.
- **Quick Reprovision**: VM recreated on a random physical node (for software issues that persist across reboot).
- **Migrate to New Host**: New VM on different physical hardware (for hardware failures).
- **Warning**: Surface an alert for review with no automated repair action.

Repair lifecycle: Cordon -> Drain -> Reboot/Reprovision/Migrate -> Rejoin

**Signal to recommended action:**

| Signal | Action |
|---|---|
| `DmesgGpuFallenOffBus` | Migrate to new host |
| `GpuSmClockThermalThrottle` | Migrate to new host |
| `GpuPcieReplayRateHigh` | Migrate to new host |
| `IBRailsDownOrDegraded` | Migrate to new host |
| `IBLinkFlapping` | Migrate to new host |
| `NpdCperHardwareErrorFatal` | Quick reprovision |
| `NpdReadonlyFilesystem` | Quick reprovision |
| `NpdXfsShutdown` | Quick reprovision |
| `DmesgXidError` | Reboot (Xid 79 migrates to new host) |
| `GpuEccDoubleBitError` | Reboot |
| `GpuRowRemapFailure` | Reboot |
| `NpdKernelDeadlock` | Reboot |
| `NpdFrequentKubeletRestart` | Reboot |
| `NpdFrequentContainerdRestart` | Reboot |
| `NpdFrequentUnregisterNetDevice` | Reboot |
| `KubeNodeMemoryPressure` | Reboot |
| `KubeNodePIDPressure` | Reboot |
| `KubeNodeDiskPressure` | Warning |
| `SlurmNodeUnavailable` | Warning |

### Monitoring Commands

```shell
# Check GPU status
nvidia-smi

# Check for Xid errors
sudo dmesg | grep -i xid

# Check GPU memory errors
nvidia-smi -q | grep -i ecc

# Check temperature and throttling
nvidia-smi -q | grep -E 'Temperature|Throttle'

# Check PCIe link status
nvidia-smi -q | grep -E 'Link Width|Link Speed'

# Check running GPU processes
nvidia-smi pmon

# Kubernetes monitoring
kubectl get nodes
kubectl top nodes
kubectl get pvc

# Slurm monitoring
sinfo
squeue
scontrol show job <jobid>
```

## User Management

### Roles

| Role | Control Plane | Data Plane |
|------|--------------|------------|
| **Admin** | Full write (create/delete/scale clusters and volumes) | Full SSH and kubectl |
| **Member** | Read-only (view only) | SSH and kubectl access |

Only admins can add or remove users. Member permissions for in-cluster operations may vary
based on RBAC configuration.

### Managing Users

1. Navigate to Settings -> GPU Cluster Projects -> View Project
2. Add User (email) or Remove User
3. New users default to Member role; admins can promote afterward

Access is always project-wide -- all clusters in a project share the same access list.

Users require active Together AI accounts before they can be added.

## Billing

### Compute

- **Reserved**: Upfront payment, 1-90 days, discounted. Non-refundable, non-cancellable.
- **On-demand**: Hourly billing, no commitment. Can terminate anytime.
- **Hybrid**: Reserved for baseline + on-demand for burst.

### Storage

- Pay-per-TiB, billed independently of cluster lifecycle
- Persists across cluster creation/deletion
- Can expand freely; contact support to reduce

### Credit Exhaustion

- **Reserved compute**: Runs until end date; overflow capacity decommissioned
- **On-demand compute**: Paused first, then decommissioned if credits not restored
- **Storage**: Access revoked, then data decommissioned

## Troubleshooting

| Issue | Solution |
|-------|----------|
| Cluster stuck provisioning | Check the status for phases like `WaitingForControlPlaneNodes` or `RunningAcceptanceTests` |
| 400 "cuda version and nvidia driver version are required" | Pass `cuda_version` and `nvidia_driver_version` as separate fields alongside `driver_version` |
| 409 "Out of stock" | GPUs unavailable in the requested region. Call `list_regions()` and try another region |
| "Shared volume does not exist in the datacenter" | Volume was created in a different datacenter partition. Use inline `shared_volume` at cluster creation instead of a separate `volume_id` |
| Pods not scheduling | Verify node readiness with `kubectl get nodes` and inspect resource requests and taints |
| GPU not accessible in container | Use a CUDA-enabled image such as `pytorch/pytorch` or `nvidia/cuda` |
| Storage PVC not binding | Confirm the volume name matches the shared volume and inspect `kubectl get pvc` |
| Slurm job failures | Run `sinfo` to inspect partitions and `scontrol show job <jobid>` for details |
| Node health issues | Check `nvidia-smi`, inspect Xid errors in `dmesg`, and trigger repair from the UI if needed |

## Terraform

```hcl
resource "together_gpu_cluster" "training" {
  name              = "training-cluster"
  num_gpus          = 8
  instance_type     = "H100-SXM"
  region            = "us-central-8"
  billing_type      = "prepaid"
  reservation_days  = 30

  shared_volume {
    name     = "training-data"
    size_tib = 5
  }
}
```

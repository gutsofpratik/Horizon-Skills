---
name: add-investor
description: >
  Adds one or more investor records to the Carta CRM via the Carta CRM MCP Server.
  Use this skill when the user says things like "add an investor", "/add-investor",
  "add investor to Carta CRM", "create investor record", "add this VC fund to the CRM", or
  "save investor data". Collects investor information conversationally, then creates
  it via the MCP server.
allowed-tools:
  - mcp__carta__crm_call_tool
  - mcp__claude_ai_Carta__crm_call_tool
  - mcp__2827383e-1775-4df3-b6ff-04d5392f6d18__crm_call_tool
version: 1.0.0
model: haiku
---

<!-- carta:plugin-version -->
<carta-plugin>carta-crm:1.15.0</carta-plugin>

## Overview

Help the user create one or more investor records in the Carta CRM using the
`create_investor` MCP tool. Collect investor details conversationally, validate
required fields, then call the tool.

## Step 1 — Discover available custom fields (optional but recommended)

Call the custom fields tool to see what fields the tenant has configured:

```
crm_call_tool({ "name": "crm:get_investor_custom_fields", "arguments": {} })
```

Use the returned field IDs and labels as hints when collecting investor data.
If the call fails, proceed without it — custom fields are optional.

## Step 2 — Collect investor information

Ask the user for:
- **Name** (required) — the investor firm name (e.g. "Sequoia Capital", "a16z")
- **Custom fields** (optional) — any fields returned in Step 1 (e.g. website, location, industry, about, tags)

If the user has already provided details in their message, extract them directly
without re-asking.

## Step 3 — Create the investor

Call:

```
crm_call_tool({
  "name": "crm:create_investor",
  "arguments": {
    name: "<investor name>",
    fields: {
      "<field_id>": "<value>"
    }
  }
})
```

Omit `fields` entirely if no custom field data was provided.

## Step 4 — Report result

On success, respond with:
> "Investor **{name}** created successfully (ID: `{id}`)."

On error, show the error message and suggest:
- Check that `name` is provided and non-empty
- Verify custom field IDs match the keys returned by `get_investor_custom_fields`

## Adding multiple investors

If the user wants to add multiple investors at once, repeat Steps 2–4 for each one.
After all are done, summarize:
> "Created N investors: [list of names with IDs]"
